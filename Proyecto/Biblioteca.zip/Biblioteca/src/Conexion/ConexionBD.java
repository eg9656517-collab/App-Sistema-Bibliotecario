package Conexion;

import Modelo.UsuarioLogin;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    private static final String URL = "jdbc:mysql://localhost:3306/biblioteca_instituto?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static Connection conexion = null;
    private static String usuarioActualBD = "";

    public static Connection conectar() {
        try {
            String user = UsuarioLogin.getUsuarioDb();
            String password = UsuarioLogin.getPasswordDb();
            if (user == null || user.isEmpty()) {
                user = "root";
                password = "Holakevo90#3"; 
            }
            
            if (conexion != null && !usuarioActualBD.equals(user)) {
                conexion.close();
                conexion = null;
            }

            if (conexion == null || conexion.isClosed()) {
                conexion = DriverManager.getConnection(URL, user, password);
                usuarioActualBD = user;
            }
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos: " + e.getMessage());
        }
        
        return conexion;
    }
}