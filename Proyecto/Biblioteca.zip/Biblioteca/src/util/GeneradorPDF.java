package util;

import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import Conexion.ConexionBD;

import javax.swing.*;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class GeneradorPDF {

    public static void exportarReportePrestamos(JFrame parentFrame) {
        Document documento = new Document();
        try {
            // Guardar el archivo en la computadora del usuario
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Guardar Reporte en PDF");
            fileChooser.setSelectedFile(new java.io.File("Reporte_Prestamos_Biblioteca.pdf"));
            
            int userSelection = fileChooser.showSaveDialog(parentFrame);
            if (userSelection != JFileChooser.APPROVE_OPTION) {
                return; // Si el usuario cancela, no hace nada
            }
            
            String rutaArchivo = fileChooser.getSelectedFile().getAbsolutePath();
            PdfWriter.getInstance(documento, new FileOutputStream(rutaArchivo));
            documento.open();

            // Título del reporte
            Font fontTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, Font.BOLD);
            Paragraph titulo = new Paragraph("Biblioteca San Juan Bautista - Reporte de Préstamos", fontTitulo);
            titulo.setAlignment(Paragraph.ALIGN_CENTER);
            documento.add(titulo);
            documento.add(new Paragraph(" ")); // Espacio en blanco

            // Crear tabla con 6 columnas
            PdfPTable tabla = new PdfPTable(6);
            tabla.setWidthPercentage(100);
            
            // Cabeceras de la tabla
            String[] cabeceras = {"ID", "F. Préstamo", "F. Devolución", "Estudiante", "Libro", "Estado"};
            for (String cabecera : cabeceras) {
                tabla.addCell(new Paragraph(cabecera, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10)));
            }

            // Consultar base de datos para rellenar filas
            String sql = "SELECT p.id_prestamo, p.fecha_prestamo, p.fecha_devolucion, " +
                         "CONCAT(e.nombre, ' ', e.apellido) AS estudiante, " +
                         "l.titulo AS libro, p.estado " +
                         "FROM prestamo p " +
                         "INNER JOIN estudiante e ON p.id_estudiante = e.id_estudiante " +
                         "INNER JOIN libro l ON p.id_libro = l.id_libro";

            try (Connection con = ConexionBD.conectar();
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    tabla.addCell(rs.getString("id_prestamo"));
                    tabla.addCell(rs.getString("fecha_prestamo"));
                    tabla.addCell(rs.getString("fecha_devolucion") != null ? rs.getString("fecha_devolucion") : "Pendiente");
                    tabla.addCell(rs.getString("estudiante"));
                    tabla.addCell(rs.getString("libro"));
                    tabla.addCell(rs.getString("estado"));
                }
            }

            documento.add(tabla);
            documento.close();
            
            JOptionPane.showMessageDialog(parentFrame, "¡Reporte PDF exportado con éxito!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parentFrame, "Error al generar el PDF: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}