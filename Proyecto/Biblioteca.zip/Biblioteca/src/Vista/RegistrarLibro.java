
package Vista;

import javax.swing.table.DefaultTableModel;

public class RegistrarLibro extends javax.swing.JFrame {
private Controlador.LibroController controlLibro = new Controlador.LibroController();
private RegistrarPrestamo ventanaPrestamo = null;
private int codigoLibroSeleccionado = -1;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(RegistrarLibro.class.getName());

    public RegistrarLibro() {
        initComponents();
        txtBuscar.setText("(Buscar Libro)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
        listarLibros();
        txtCodigo.setEnabled(false);
        cargarCategoriasEnComboBox();
        txtAutor.setText("Doble click para seleccionar en registro");
        txtAutor.setForeground(new java.awt.Color(153, 153, 153));
    }
public RegistrarLibro(RegistrarPrestamo ventanaPrestamo) {
    this();
    this.ventanaPrestamo = ventanaPrestamo;
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        txtTitulo = new javax.swing.JTextField();
        txtAutor = new javax.swing.JTextField();
        txtEditorial = new javax.swing.JTextField();
        txtUbicacion = new javax.swing.JTextField();
        cbxDisponibilidad = new javax.swing.JComboBox<>();
        cbxCategoria = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaLibros = new javax.swing.JTable();
        btnGuardar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        txtAnoDisponibilidad = new javax.swing.JFormattedTextField();
        spnCantidad = new javax.swing.JSpinner();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        LupaEdi = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, -1, -1));

        jLabel3.setText("Codigo:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        jLabel4.setText("Titulo:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, -1, -1));

        jLabel5.setText("Autor:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, -1, -1));

        jLabel6.setText("Categoria:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, -1, -1));

        jLabel7.setText("Editorial:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 70, -1, -1));

        jLabel8.setText("Año publicacion:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 100, -1, -1));

        jLabel9.setText("Disponibilidad:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 140, -1, -1));

        jLabel10.setText("Cantidad:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 200, -1, -1));

        txtCodigo.setEditable(false);
        getContentPane().add(txtCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 160, -1));
        getContentPane().add(txtTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, 160, -1));

        txtAutor.setEnabled(false);
        getContentPane().add(txtAutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 240, -1));

        txtEditorial.setEditable(false);
        txtEditorial.setEnabled(false);
        getContentPane().add(txtEditorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 70, 160, -1));

        txtUbicacion.addActionListener(this::txtUbicacionActionPerformed);
        getContentPane().add(txtUbicacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 170, 160, -1));

        cbxDisponibilidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Disponible", "Prestado" }));
        cbxDisponibilidad.addActionListener(this::cbxDisponibilidadActionPerformed);
        getContentPane().add(cbxDisponibilidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 140, 160, -1));

        getContentPane().add(cbxCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 230, -1));

        tablaLibros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Titulo", "Autor", "Categoria", "Editorial", "Año pub", "Disp.", "Cant.", "Ubic."
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaLibros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaLibrosMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaLibros);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 890, 310));

        btnGuardar.setBackground(new java.awt.Color(117, 189, 107));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 570, 80, 40));

        btnActualizar.setBackground(new java.awt.Color(73, 144, 180));
        btnActualizar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(this::btnActualizarActionPerformed);
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 570, 90, 40));

        btnEliminar.setBackground(new java.awt.Color(244, 67, 54));
        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 570, 90, 40));

        btnCancelar.setBackground(new java.awt.Color(153, 153, 153));
        btnCancelar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelar.setText("Limpiar");
        btnCancelar.addActionListener(this::btnCancelarActionPerformed);
        getContentPane().add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 570, 90, 40));

        jLabel11.setText("Busqueda:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addActionListener(this::txtBuscarActionPerformed);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 210, -1));

        try {
            txtAnoDisponibilidad.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        getContentPane().add(txtAnoDisponibilidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 100, 160, -1));

        spnCantidad.setModel(new javax.swing.SpinnerNumberModel(0, 0, 200, 1));
        getContentPane().add(spnCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 200, 160, -1));

        jLabel12.setText("Ubicacion:");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 170, -1, -1));
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Registrar libros");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 20, -1, -1));

        jButton1.setText("...");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 100, -1, -1));

        LupaEdi.setText("...");
        LupaEdi.addActionListener(this::LupaEdiActionPerformed);
        getContentPane().add(LupaEdi, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 70, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void listarLibros() {
    java.util.List<Modelo.Libro> lista = controlLibro.obtenerTodos();
    DefaultTableModel modelo = (DefaultTableModel) tablaLibros.getModel();
    modelo.setRowCount(0);
    Object[] fila = new Object[9]; 
    for (Modelo.Libro l : lista) {
        fila[0] = l.getCodigo();
        fila[1] = l.getTitulo();
        fila[2] = l.getAutor();
        fila[3] = l.getCategoria();
        fila[4] = l.getEditorial();
        fila[5] = l.getAnoPublicacion();
        fila[6] = l.getDisponibilidad();
        fila[7] = l.getCantidad();
        fila[8] = l.getUbicacion();
        
        modelo.addRow(fila);
    }
}
public void cargarCategoriasEnComboBox() {
    Modelo.DAOCategoria daoCat = new Modelo.DAOCategoria();
    java.util.List<Modelo.Categoria> lista = daoCat.listarCategorias(); 
    
    cbxCategoria.removeAllItems(); 
    cbxCategoria.addItem("— Seleccione una Categoría —");
    for (Modelo.Categoria c : lista) {
        cbxCategoria.addItem(c.getNombre()); 
    }
}
public void limpiarCampos() {
    txtCodigo.setText("");
    txtTitulo.setText("");
    txtAutor.setText("");
    cbxCategoria.setSelectedIndex(0);
    txtEditorial.setText("");
    txtAnoDisponibilidad.setText("");
    cbxDisponibilidad.setSelectedIndex(0);
    txtUbicacion.setText("");
    txtBuscar.setText("");
    spnCantidad.setValue(0);
    txtBuscar.setText("(Buscar Libro)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
         txtAutor.setText("Doble click para seleccionar en registro");
        txtAutor.setForeground(new java.awt.Color(153, 153, 153));
}
public void restablecerFormulario() {
    limpiarCampos();
    listarLibros();
    codigoLibroSeleccionado = -1; 
    tablaLibros.clearSelection(); 
    btnGuardar.setEnabled(true);
    
}
    private void cbxDisponibilidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxDisponibilidadActionPerformed
      
    }//GEN-LAST:event_cbxDisponibilidadActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
   String titulo = txtTitulo.getText().trim();
    String autor = txtAutor.getText().trim();
    String editorial = txtEditorial.getText().trim();
    String anoPub = txtAnoDisponibilidad.getText().trim();
    String ubicacion = txtUbicacion.getText().trim();
    
    if (titulo.isEmpty() || autor.isEmpty() || editorial.isEmpty() || anoPub.isEmpty() || ubicacion.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, llene todos los campos de texto del formulario.", "Campos Vacíos", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    if (autor.equalsIgnoreCase("Doble click para seleccionar en registro")) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, use el botón (...) para seleccionar un autor válido de la lista, haga doble click en la lista para seleccionar.", "Autor No Válido", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    if (!anoPub.matches("\\d{4}")) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, ingrese un año de publicación válido de 4 dígitos (ej. 2024).", "Año No Válido", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtAnoDisponibilidad.requestFocus();
        return;
    }

    if (cbxCategoria.getSelectedIndex() == 0 || cbxCategoria.getSelectedItem().toString().equals("— Seleccione una Categoría —")) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione una categoría válida para el libro.", "Categoría requerida", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    if (cbxDisponibilidad.getSelectedItem() == null) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione el estado de disponibilidad.", "Disponibilidad requerida", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    int cantidad = (int) spnCantidad.getValue();
    if (cantidad <= 0) {
        javax.swing.JOptionPane.showMessageDialog(this, "La cantidad de libros a registrar debe ser mayor a 0.", "Cantidad No Válida", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
if (controlLibro.existeLibroPorTitulo(titulo, -1)) {
    javax.swing.JOptionPane.showMessageDialog(this, 
            "El libro con el título '" + titulo + "' ya se encuentra registrado.", 
            "Título Duplicado", 
            javax.swing.JOptionPane.WARNING_MESSAGE);
    txtTitulo.requestFocus();
    return;
}
    Modelo.Libro l = new Modelo.Libro();
    l.setTitulo(titulo);
    l.setAutor(autor);
    l.setCategoria(cbxCategoria.getSelectedItem().toString());
    l.setEditorial(editorial);
    l.setAnoPublicacion(anoPub);
    l.setDisponibilidad(cbxDisponibilidad.getSelectedItem().toString());
    l.setUbicacion(ubicacion);
    l.setCantidad(cantidad);

    if (controlLibro.registrar(
            l.getTitulo(), 
            l.getAutor(), 
            l.getCategoria(), 
            l.getEditorial(), 
            l.getAnoPublicacion(), 
            l.getDisponibilidad(), 
            l.getUbicacion(), 
            l.getCantidad())) {
        
        javax.swing.JOptionPane.showMessageDialog(this, "Libro registrado con éxito.", "Éxito", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        listarLibros(); 
        limpiarCampos();
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al registrar el libro en la base de datos.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void tablaLibrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaLibrosMouseClicked
int fila = tablaLibros.getSelectedRow();
    
    if (fila == -1) {
        return;
    }
    if (evt.getClickCount() == 2) {
    if (ventanaPrestamo != null) {
        String tituloLibro = tablaLibros.getValueAt(fila, 1).toString();
        ventanaPrestamo.txtTituloLibro.setText(tituloLibro);
        ventanaPrestamo.actualizarStockInformativo(); 
        this.dispose();
    }
}

    else if (evt.getClickCount() == 1) {int filaSeleccionada = tablaLibros.getSelectedRow();
    if (filaSeleccionada >= 0) {
        this.codigoLibroSeleccionado = Integer.parseInt(tablaLibros.getValueAt(filaSeleccionada, 0).toString());
        txtCodigo.setText(tablaLibros.getValueAt(filaSeleccionada, 0).toString());
        txtTitulo.setText(tablaLibros.getValueAt(filaSeleccionada, 1).toString());
        txtAutor.setText(tablaLibros.getValueAt(filaSeleccionada, 2).toString());
        cbxCategoria.setSelectedItem(tablaLibros.getValueAt(filaSeleccionada, 3).toString());
        txtEditorial.setText(tablaLibros.getValueAt(filaSeleccionada, 4).toString());
        txtAnoDisponibilidad.setText(tablaLibros.getValueAt(filaSeleccionada, 5).toString());
        cbxDisponibilidad.setSelectedItem(tablaLibros.getValueAt(filaSeleccionada, 6).toString());
        int cantidad = Integer.parseInt(tablaLibros.getValueAt(filaSeleccionada, 7).toString());
        spnCantidad.setValue(cantidad);
        txtUbicacion.setText(tablaLibros.getValueAt(filaSeleccionada, 8).toString());
    }
    }
    btnGuardar.setEnabled(false);
    }//GEN-LAST:event_tablaLibrosMouseClicked

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
if (txtCodigo.getText().trim().isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione un libro de la tabla para actualizar.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    int idLibro = Integer.parseInt(txtCodigo.getText().trim());
    String titulo = txtTitulo.getText().trim();
    String autor = txtAutor.getText().trim();
    String editorial = txtEditorial.getText().trim();
    String anoPub = txtAnoDisponibilidad.getText().trim();
    String ubicacion = txtUbicacion.getText().trim();

    if (titulo.isEmpty() || autor.isEmpty() || editorial.isEmpty() || anoPub.isEmpty() || ubicacion.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, llene todos los campos de texto antes de actualizar.", "Campos Vacíos", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    if (autor.equalsIgnoreCase("Doble click para seleccionar en registro")) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, use el botón (...) para seleccionar un autor válido de la lista.", "Autor No Válido", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    if (!anoPub.matches("\\d{4}")) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, ingrese un año de publicación válido de 4 dígitos (ej. 2024).", "Año No Válido", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtAnoDisponibilidad.requestFocus();
        return;
    }

    if (cbxCategoria.getSelectedIndex() == 0 || cbxCategoria.getSelectedItem().toString().equals("— Seleccione una Categoría —")) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione una categoría válida.", "Categoría requerida", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    if (cbxDisponibilidad.getSelectedItem() == null) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione el estado de disponibilidad.", "Disponibilidad requerida", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    int cantidad = (int) spnCantidad.getValue();
    if (cantidad <= 0) {
        javax.swing.JOptionPane.showMessageDialog(this, "La cantidad de libros debe ser mayor a 0.", "Cantidad No Válida", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

   if (controlLibro.existeLibroPorTitulo(titulo, idLibro)) {
    javax.swing.JOptionPane.showMessageDialog(this, 
            "Ya existe otro libro registrado con el título '" + titulo + "'.", 
            "Título Duplicado", 
            javax.swing.JOptionPane.WARNING_MESSAGE);
    txtTitulo.requestFocus();
    return;
}

    Modelo.Libro l = new Modelo.Libro();
    l.setCodigo(idLibro);
    l.setTitulo(titulo);
    l.setAutor(autor);
    l.setCategoria(cbxCategoria.getSelectedItem().toString());
    l.setEditorial(editorial);
    l.setAnoPublicacion(anoPub);
    l.setDisponibilidad(cbxDisponibilidad.getSelectedItem().toString());
    l.setUbicacion(ubicacion);
    l.setCantidad(cantidad);

    if (controlLibro.actualizarLibro(
            l.getCodigo(), 
            l.getTitulo(), 
            l.getAutor(), 
            l.getCategoria(), 
            l.getEditorial(), 
            l.getAnoPublicacion(), 
            l.getDisponibilidad(), 
            l.getUbicacion(), 
            l.getCantidad())) {
        
        javax.swing.JOptionPane.showMessageDialog(this, "Libro actualizado con éxito.", "Éxito", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        listarLibros();
        limpiarCampos();
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al actualizar el libro.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
restablecerFormulario();   
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
if (codigoLibroSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione un libro de la tabla para poder eliminarlo.");
        return;
    }

    String tituloLibro = txtTitulo.getText().trim();

    int respuesta = javax.swing.JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de eliminar permanentemente el libro: '" + tituloLibro + "'?", 
            "Confirmar Baja", 
            javax.swing.JOptionPane.YES_NO_OPTION, 
            javax.swing.JOptionPane.WARNING_MESSAGE);

    if (respuesta == javax.swing.JOptionPane.YES_OPTION) {
        controlLibro.eliminarLibro(codigoLibroSeleccionado);
        
        restablecerFormulario();
        
        javax.swing.JOptionPane.showMessageDialog(this, "El libro fue removido del catálogo.");
    }
    
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
String texto = txtBuscar.getText().trim();
    java.util.List<Modelo.Libro> filtrada = controlLibro.buscarLibro(texto);
    
    DefaultTableModel modelo = (DefaultTableModel) tablaLibros.getModel();
    modelo.setRowCount(0);
    
    Object[] fila = new Object[9];
    for (Modelo.Libro l : filtrada) {
      fila[0] = l.getCodigo();
    fila[1] = l.getTitulo();
    fila[2] = l.getAutor();
    fila[3] = l.getCategoria();
    fila[4] = l.getEditorial();
    fila[5] = l.getAnoPublicacion();
    fila[6] = l.getDisponibilidad();
    fila[7] = l.getCantidad(); 
    fila[8] = l.getUbicacion();
        modelo.addRow(fila);
    }
   
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained
     if (txtBuscar.getText().equals("(Buscar Libro)")) {
        txtBuscar.setText("");
        txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
    }
    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
      if (txtBuscar.getText().trim().isEmpty()) {
        txtBuscar.setText("(Buscar Libro)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }
    }//GEN-LAST:event_txtBuscarFocusLost

    private void txtUbicacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUbicacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUbicacionActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 RegistrarAutor dialogAutor = new RegistrarAutor(this, true);
    dialogAutor.setLocationRelativeTo(this);
    dialogAutor.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void LupaEdiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LupaEdiActionPerformed
        RegistrarEditorial dialogEditorial = new RegistrarEditorial(this, true);
    dialogEditorial.setLocationRelativeTo(this);
    dialogEditorial.setVisible(true);
    }//GEN-LAST:event_LupaEdiActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new RegistrarLibro().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LupaEdi;
    public javax.swing.JButton btnActualizar;
    public javax.swing.JButton btnCancelar;
    public javax.swing.JButton btnEliminar;
    public javax.swing.JButton btnGuardar;
    public javax.swing.JComboBox<String> cbxCategoria;
    public javax.swing.JComboBox<String> cbxDisponibilidad;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JSpinner spnCantidad;
    public javax.swing.JTable tablaLibros;
    private javax.swing.JFormattedTextField txtAnoDisponibilidad;
    public javax.swing.JTextField txtAutor;
    public javax.swing.JTextField txtBuscar;
    public javax.swing.JTextField txtCodigo;
    public javax.swing.JTextField txtEditorial;
    public javax.swing.JTextField txtTitulo;
    public javax.swing.JTextField txtUbicacion;
    // End of variables declaration//GEN-END:variables
}
