
package Vista;

import javax.swing.table.DefaultTableModel;

public class EliminarUsuario extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(EliminarUsuario.class.getName());
private Controlador.UsuarioController controlUsuario = new Controlador.UsuarioController();

    public EliminarUsuario() {
        initComponents();
        txtBuscar.setText("(Buscar usuario por Nombre)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
        listarUsuarios();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaEliminar = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Eliminar usuario del sistema");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, -1, -1));

        jLabel2.setText("Buscar:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addActionListener(this::txtBuscarActionPerformed);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 260, -1));

        tablaEliminar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Email", "Rol", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaEliminar);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 510, 220));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setBackground(new java.awt.Color(244, 67, 54));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Confirmar eliminacion");
        jButton2.addActionListener(this::jButton2ActionPerformed);
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 160, 40));

        jButton3.setBackground(new java.awt.Color(117, 189, 107));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Salir");
        jButton3.addActionListener(this::jButton3ActionPerformed);
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, 110, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 510, 60));

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void listarUsuarios() {
   String filtro = txtBuscar.getText().trim();

if (filtro.equals("(Buscar usuario por Nombre)")) {
    filtro = ""; 
}
    java.util.List<Modelo.Usuario> lista = controlUsuario.obtenerTodos(); 
    DefaultTableModel modelo = (DefaultTableModel) tablaEliminar.getModel();
    modelo.setRowCount(0);
    Object[] fila = new Object[5]; 
    for (Modelo.Usuario u : lista) {
        fila[0] = u.getId();
        fila[1] = u.getNombreCompleto();
        fila[2] = u.getCorreo();
        fila[3] = u.getRol();
        fila[4] = "Activo";
        
        modelo.addRow(fila);
    }
}
    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
    String texto = txtBuscar.getText().trim();
    java.util.List<Modelo.Usuario> filtrada = controlUsuario.buscarUsuario(texto);
    
    DefaultTableModel modelo = (DefaultTableModel) tablaEliminar.getModel();
    modelo.setRowCount(0);
    
    Object[] fila = new Object[5];
    for (Modelo.Usuario u : filtrada) {
        fila[0] = u.getId();
        fila[1] = u.getNombreCompleto();
        fila[2] = u.getCorreo();
        fila[3] = u.getRol();
        fila[4] = "Activo";
        modelo.addRow(fila);
    }

    }//GEN-LAST:event_txtBuscarKeyReleased

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
int filaSeleccionada = tablaEliminar.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Seleccione un usuario de la tabla para eliminar.", 
            "Advertencia", 
            javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    int idEliminar = Integer.parseInt(tablaEliminar.getValueAt(filaSeleccionada, 0).toString());
    String nombreUser = tablaEliminar.getValueAt(filaSeleccionada, 1).toString();
    int respuesta = javax.swing.JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de que desea eliminar permanentemente al usuario: " + nombreUser + " (ID: " + idEliminar + ")?", 
            "Confirmar Baja del Sistema", 
            javax.swing.JOptionPane.YES_NO_OPTION, 
            javax.swing.JOptionPane.WARNING_MESSAGE);

    if (respuesta == javax.swing.JOptionPane.YES_OPTION) {
        controlUsuario.eliminarUsuario(idEliminar);
        listarUsuarios();
        javax.swing.JOptionPane.showMessageDialog(this, 
            "El usuario ha sido removido del sistema exitosamente.", 
            "Operación Completada", 
            javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained
    if (txtBuscar.getText().equals("(Buscar usuario por Nombre)")) {
        txtBuscar.setText("");
        txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
    }

    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
      if (txtBuscar.getText().trim().isEmpty()) {
        txtBuscar.setText("(Buscar usuario por Nombre)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }

    }//GEN-LAST:event_txtBuscarFocusLost

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new EliminarUsuario().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaEliminar;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
