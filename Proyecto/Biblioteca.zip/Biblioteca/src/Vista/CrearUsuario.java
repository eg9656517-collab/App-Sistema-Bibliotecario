
package Vista;
import Controlador.UsuarioController;
import Modelo.Usuario;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class CrearUsuario extends javax.swing.JFrame {
    private int idSeleccionado = -1;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CrearUsuario.class.getName());
private Controlador.UsuarioController controlUsuario = new Controlador.UsuarioController();
    public CrearUsuario() {
        initComponents();
        txtBuscar.setText("(Buscar usuario)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
        btnActualizar.setEnabled(false);
        listar();
       
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtNombreCompleto = new javax.swing.JTextField();
        txtNombreUsuario = new javax.swing.JTextField();
        txtCorreo = new javax.swing.JTextField();
        cbRol = new javax.swing.JComboBox<>();
        txtContrasena = new javax.swing.JPasswordField();
        txtBuscar = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaUsuarios = new javax.swing.JTable();
        btnCancelar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        txtConfirmarContrasena = new javax.swing.JPasswordField();
        jLabel10 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel1.setText("Nuevo usuario");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, -1, -1));

        jLabel2.setText("Nombre completo:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        jLabel3.setText("Nombre de usuario:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel5.setText("Contraseña:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, -1, 20));

        jLabel6.setText("Correo:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, -1, -1));

        jLabel7.setText("Telefono:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 100, -1, -1));

        jLabel8.setText("Rol:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, -1, -1));
        getContentPane().add(txtNombreCompleto, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, 110, -1));
        getContentPane().add(txtNombreUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 110, -1));
        getContentPane().add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 70, 110, -1));

        cbRol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "— Seleccione un Rol —", "Administrador", "Bibliotecario" }));
        cbRol.addActionListener(this::cbRolActionPerformed);
        getContentPane().add(cbRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 130, 170, -1));
        getContentPane().add(txtContrasena, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 110, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 170, -1));

        jLabel9.setText("Buscar:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        tablaUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre com", "Nombre usuario", "Contraseña", "Correo", "Telefono", "Rol"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaUsuariosMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaUsuarios);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 540, 200));

        btnCancelar.setBackground(new java.awt.Color(153, 153, 153));
        btnCancelar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelar.setText("Limpiar");
        btnCancelar.addActionListener(this::btnCancelarActionPerformed);
        getContentPane().add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 450, 130, 30));

        btnGuardar.setBackground(new java.awt.Color(117, 189, 107));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 450, 130, 30));

        btnActualizar.setBackground(new java.awt.Color(73, 144, 180));
        btnActualizar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(this::btnActualizarActionPerformed);
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 450, 110, 30));
        getContentPane().add(txtConfirmarContrasena, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, 110, -1));

        jLabel10.setText("Confirmar contraseña:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, 20));
        getContentPane().add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 100, 100, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbRolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRolActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbRolActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
String nc = txtNombreCompleto.getText().trim();
    String nu = txtNombreUsuario.getText().trim();
    String pass = new String(txtContrasena.getPassword());
    String confirm = new String(txtConfirmarContrasena.getPassword());
    String correo = txtCorreo.getText().trim();
    String tel = txtTelefono.getText().trim();
    String rol = cbRol.getSelectedItem() != null ? cbRol.getSelectedItem().toString() : "";

    // 1. Validar campos vacíos
    if (nc.isEmpty() || nu.isEmpty() || pass.isEmpty() || confirm.isEmpty() || correo.isEmpty() || tel.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, complete todos los campos del formulario.", 
            "Campos Incompletos", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    // 2. Validar selección de rol
    if (cbRol.getSelectedIndex() == 0 || rol.equals("— Seleccione un Rol —")) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, seleccione un rol válido para el usuario.", 
            "Rol Requerido", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    // 3. Validar correo electrónico (que tenga '@' y formato de dominio válido)
    String regexCorreo = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
    if (!correo.matches(regexCorreo)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, ingrese un correo electrónico válido (ej. usuario@dominio.com).", 
            "Correo No Válido", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtCorreo.requestFocus();
        return;
    }

   if (!tel.matches("\\d{8}")) {
    javax.swing.JOptionPane.showMessageDialog(this, 
        "Por favor, ingrese un número de teléfono válido de 8 dígitos (solo números).", 
        "Teléfono No Válido", javax.swing.JOptionPane.WARNING_MESSAGE);
    txtTelefono.requestFocus();
    return;
}

    if (!pass.equals(confirm)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Las contraseñas no coinciden. Por favor, verifíquelas.", 
            "Error de Validación", javax.swing.JOptionPane.ERROR_MESSAGE);
        txtConfirmarContrasena.requestFocus();
        return;
    }
    try {
        if (controlUsuario.registrar(nc, nu, pass, correo, tel, rol)) {
            listar(); 
            limpiarCampos();
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Usuario creado con éxito en el sistema.", 
                "Éxito", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "El nombre de usuario '" + nu + "' ya se encuentra registrado.", 
                "Usuario Duplicado", javax.swing.JOptionPane.WARNING_MESSAGE);
            txtNombreUsuario.requestFocus();
        }
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Error de comunicación con la base de datos: " + e.getMessage(), 
            "Error Crítico", javax.swing.JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void tablaUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaUsuariosMouseClicked
int filaSeleccionada = tablaUsuarios.getSelectedRow();
    
    if (filaSeleccionada == -1) {
        return;
    }
    idSeleccionado = Integer.parseInt(tablaUsuarios.getValueAt(filaSeleccionada, 0).toString());
    String nombreCompleto = String.valueOf(tablaUsuarios.getValueAt(filaSeleccionada, 1));
    String nombreUsuario  = String.valueOf(tablaUsuarios.getValueAt(filaSeleccionada, 2));
    String contrasena     = String.valueOf(tablaUsuarios.getValueAt(filaSeleccionada, 3));
    String correo         = String.valueOf(tablaUsuarios.getValueAt(filaSeleccionada, 4));
    String telefono       = String.valueOf(tablaUsuarios.getValueAt(filaSeleccionada, 5));
    String rol            = String.valueOf(tablaUsuarios.getValueAt(filaSeleccionada, 6)).trim();
    txtNombreCompleto.setText(nombreCompleto);
    txtNombreUsuario.setText(nombreUsuario);
    txtContrasena.setText(contrasena);
    txtConfirmarContrasena.setText(contrasena); 
    txtCorreo.setText(correo);
 
    if (telefono.equals("null") || telefono.isEmpty()) {
        txtTelefono.setText("");
    } else {
        txtTelefono.setText(telefono);
    }
    cbRol.setSelectedItem(rol);
    btnGuardar.setEnabled(false);  
    txtNombreUsuario.setEditable(false);
    txtNombreUsuario.setEnabled(false);
    btnActualizar.setEnabled(true);
   
    }//GEN-LAST:event_tablaUsuariosMouseClicked

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
 if (idSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Seleccione un usuario de la tabla para actualizar.", 
            "Error de Selección", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    String nc = txtNombreCompleto.getText().trim();
    String nu = txtNombreUsuario.getText().trim(); 
    String pass = new String(txtContrasena.getPassword());
    String confirm = new String(txtConfirmarContrasena.getPassword());
    String correo = txtCorreo.getText().trim();
    String tel = txtTelefono.getText().trim();
    String rol = cbRol.getSelectedItem() != null ? cbRol.getSelectedItem().toString() : "";

   
    if (nc.isEmpty() || nu.isEmpty() || pass.isEmpty() || confirm.isEmpty() || correo.isEmpty() || tel.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Asegúrese de que ningún campo quede vacío antes de actualizar.", 
            "Campos Incompletos", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    if (cbRol.getSelectedIndex() == 0 || rol.equals("— Seleccione un Rol —")) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, asigne un rol válido para continuar.", 
            "Rol Requerido", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    String regexCorreo = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
    if (!correo.matches(regexCorreo)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, ingrese un correo electrónico válido (ej. usuario@dominio.com).", 
            "Correo No Válido", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtCorreo.requestFocus();
        return;
    }
    if (!tel.matches("\\d{8}")) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, ingrese un número de teléfono válido de 8 dígitos (solo números).", 
            "Teléfono No Válido", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtTelefono.requestFocus();
        return;
    }

    if (!pass.equals(confirm)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Las contraseñas no coinciden. Por favor, verifíquelas.", 
            "Error de Validación", javax.swing.JOptionPane.ERROR_MESSAGE);
        txtConfirmarContrasena.requestFocus();
        return;
    }

    try {
        controlUsuario.actualizar(idSeleccionado, nc, nu, pass, correo, tel, rol);
        listar();         
        limpiarCampos();   
        idSeleccionado = -1; 
        btnGuardar.setEnabled(true);
        txtNombreUsuario.setEditable(true);
        tablaUsuarios.clearSelection(); 
        
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Datos del usuario actualizados correctamente.", 
            "Actualización Exitosa", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Error al actualizar el usuario: " + e.getMessage(), 
            "Error del Servidor", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    
    if (txtBuscar != null) {
        txtBuscar.setText("(Buscar usuario)");
    }

    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
    limpiarCampos();
     txtBuscar.setText("(Buscar usuario)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
   String textoBuscar = txtBuscar.getText().trim();
  
    java.util.List<Usuario> listaFiltrada = controlUsuario.buscarUsuario(textoBuscar); 

    DefaultTableModel modelo = (DefaultTableModel) tablaUsuarios.getModel();
    modelo.setRowCount(0); 
 
    Object[] fila = new Object[7]; 
    for (Usuario u : listaFiltrada) {
        fila[0] = u.getId();
        fila[1] = u.getNombreCompleto(); 
        fila[2] = u.getNombreUsuario();   
        fila[3] = u.getContrasena();      
        fila[4] = u.getCorreo();          
        fila[5] = u.getTelefono();       
        fila[6] = u.getRol();             
        
        modelo.addRow(fila);
    }

    }//GEN-LAST:event_txtBuscarKeyReleased

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained
       if (txtBuscar.getText().equals("(Buscar usuario)")) {
        txtBuscar.setText("");
        txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
    }
    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
 if (txtBuscar.getText().trim().isEmpty()) {
        txtBuscar.setText("(Buscar usuario)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }
    }//GEN-LAST:event_txtBuscarFocusLost
public void listar() {
   List<Usuario> lista = controlUsuario.obtenerTodos(); 
    DefaultTableModel modelo = (DefaultTableModel) tablaUsuarios.getModel();
    modelo.setRowCount(0);
    
    Object[] fila = new Object[7]; 
    for (Usuario u : lista) {
        fila[0] = u.getId();            
        fila[1] = u.getNombreCompleto(); 
        fila[2] = u.getNombreUsuario();   
        fila[3] = u.getContrasena();     
        fila[4] = u.getCorreo();       
        fila[5] = u.getTelefono();       
        fila[6] = u.getRol();
        
        modelo.addRow(fila);
    }
}
public void limpiarCampos() {
    txtNombreCompleto.setText("");
    txtNombreUsuario.setText("");
    txtContrasena.setText("");
    txtConfirmarContrasena.setText("");
     txtBuscar.setText("");
    txtCorreo.setText("");
    txtTelefono.setText("");
    cbRol.setSelectedIndex(0); 
    txtBuscar.setText("(Buscar usuario)");
    btnActualizar.setEnabled(false);
    btnGuardar.setEnabled(true);
    txtNombreUsuario.setEditable(true);
    txtNombreUsuario.setEnabled(true);
}
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new CrearUsuario().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnActualizar;
    public javax.swing.JButton btnCancelar;
    public javax.swing.JButton btnGuardar;
    public javax.swing.JComboBox<String> cbRol;
    public javax.swing.JLabel jLabel1;
    public javax.swing.JLabel jLabel10;
    public javax.swing.JLabel jLabel2;
    public javax.swing.JLabel jLabel3;
    public javax.swing.JLabel jLabel5;
    public javax.swing.JLabel jLabel6;
    public javax.swing.JLabel jLabel7;
    public javax.swing.JLabel jLabel8;
    public javax.swing.JLabel jLabel9;
    public javax.swing.JScrollPane jScrollPane2;
    public javax.swing.JTable tablaUsuarios;
    public javax.swing.JTextField txtBuscar;
    private javax.swing.JPasswordField txtConfirmarContrasena;
    public javax.swing.JPasswordField txtContrasena;
    public javax.swing.JTextField txtCorreo;
    public javax.swing.JTextField txtNombreCompleto;
    public javax.swing.JTextField txtNombreUsuario;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
