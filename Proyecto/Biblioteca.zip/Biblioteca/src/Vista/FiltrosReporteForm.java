package Vista;

public class FiltrosReporteForm extends javax.swing.JInternalFrame {
    private ReportesForm reportesFormPadre;
    
    
    public FiltrosReporteForm() {
        initComponents();
        cargarCategoriasEnComboBox();
        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        ajustarCamposSegunSeleccion();
    }
    
    public FiltrosReporteForm(ReportesForm parent) {
        initComponents();
        this.reportesFormPadre = parent;
        cargarCategoriasEnComboBox();
        setClosable(true);
        setIconifiable(true);
        setResizable(true);
    }
    
public void cargarCategoriasEnComboBox() {
        Modelo.DAOCategoria daoCat = new Modelo.DAOCategoria();
        java.util.List<Modelo.Categoria> lista = daoCat.listarCategorias();
        cbxCategoria.removeAllItems();
        cbxCategoria.addItem("Todas las categorías"); 
        for (Modelo.Categoria c : lista) {
            cbxCategoria.addItem(c.getNombre());
        }
    }

private void ajustarCamposSegunSeleccion() {
    String tipo = cbxTipoFiltro.getSelectedItem() != null ? cbxTipoFiltro.getSelectedItem().toString().trim() : "";
    boolean esInventario = tipo.equalsIgnoreCase("Inventario de libros");
    boolean esSecciones = tipo.contains("Secciones");
    boolean esLibrosPopulares = tipo.contains("Libros mas Prestados") || tipo.contains("Libros más Prestados");
    
    // inventario libros
    if (esInventario) {
        cbxCategoria.setEnabled(true);
        txtSeccion.setEnabled(false);
        txtSeccion.setText(""); 
        if (jDateChooserDesde != null) jDateChooserDesde.setEnabled(false);
        if (jDateChooserHasta != null) jDateChooserHasta.setEnabled(false);
    } 
    // Secciones populares
    else if (esSecciones) {
        cbxCategoria.setEnabled(false);
        txtSeccion.setEnabled(false);
        if (jDateChooserDesde != null) jDateChooserDesde.setEnabled(true);
        if (jDateChooserHasta != null) jDateChooserHasta.setEnabled(true);
    } 
    // Prestamos generales y libros 
    else {
        cbxCategoria.setEnabled(true);
        txtSeccion.setEnabled(!esLibrosPopulares);
        if (jDateChooserDesde != null) jDateChooserDesde.setEnabled(true);
        if (jDateChooserHasta != null) jDateChooserHasta.setEnabled(true);
    }
}

public void aplicarFiltros() {
    String tipoFiltro = cbxTipoFiltro.getSelectedItem().toString();
    String categoria = cbxCategoria.getSelectedItem().toString();
    String seccion = txtSeccion.getText().trim();
    java.util.Date fechaD = jDateChooserDesde != null ? jDateChooserDesde.getDate() : null;
    java.util.Date fechaH = jDateChooserHasta != null ? jDateChooserHasta.getDate() : null;
    if (reportesFormPadre != null) {
        reportesFormPadre.actualizarReporteConFiltros(tipoFiltro, categoria, seccion, fechaD, fechaH);
    }
    
    this.dispose();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jDateChooserHasta = new com.toedter.calendar.JDateChooser();
        jDateChooserDesde = new com.toedter.calendar.JDateChooser();
        jLabel3 = new javax.swing.JLabel();
        cbxTipoFiltro = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cbxCategoria = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        txtSeccion = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Parametros", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-5, 22, 510, 10));

        jLabel1.setText("Fecha desde:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 98, -1, -1));

        jLabel2.setText("Fecha hasta:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 98, -1, -1));
        jPanel1.add(jDateChooserHasta, new org.netbeans.lib.awtextra.AbsoluteConstraints(359, 92, 141, -1));
        jPanel1.add(jDateChooserDesde, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 92, 141, -1));

        jLabel3.setText("Tipo de filtro:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 47, -1, -1));

        cbxTipoFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos los prestamos", "Prestamos Activos", "Prestamos Vencidos", "Libros mas Prestados", "Secciones con mas prestamos", "Inventario de libros" }));
        cbxTipoFiltro.addItemListener(this::cbxTipoFiltroItemStateChanged);
        cbxTipoFiltro.addActionListener(this::cbxTipoFiltroActionPerformed);
        jPanel1.add(cbxTipoFiltro, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 44, 224, -1));
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 181, -1, -1));

        jLabel5.setText("Categoria de libro:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 156, -1, -1));

        jPanel1.add(cbxCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 153, 204, -1));

        jLabel6.setText("Seccion:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 202, -1, -1));
        jPanel1.add(txtSeccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 199, 204, -1));

        jButton1.setBackground(new java.awt.Color(102, 255, 102));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Aplicar filtros");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     aplicarFiltros();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cbxTipoFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxTipoFiltroActionPerformed
    // missclick
    }//GEN-LAST:event_cbxTipoFiltroActionPerformed

    private void cbxTipoFiltroItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxTipoFiltroItemStateChanged
       if (evt.getStateChange() == java.awt.event.ItemEvent.SELECTED) {
        ajustarCamposSegunSeleccion();
    }
    }//GEN-LAST:event_cbxTipoFiltroItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxCategoria;
    private javax.swing.JComboBox<String> cbxTipoFiltro;
    private javax.swing.JButton jButton1;
    private com.toedter.calendar.JDateChooser jDateChooserDesde;
    private com.toedter.calendar.JDateChooser jDateChooserHasta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField txtSeccion;
    // End of variables declaration//GEN-END:variables
}
