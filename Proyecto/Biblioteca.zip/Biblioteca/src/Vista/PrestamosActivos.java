
package Vista;

import Controlador.LibroController;
import javax.swing.table.DefaultTableModel;

public class PrestamosActivos extends javax.swing.JFrame {
     private Controlador.PrestamoController controlPrestamo = new Controlador.PrestamoController();
     LibroController controlLibro = new LibroController();
     private int idPrestamoSeleccionado = -1;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PrestamosActivos.class.getName());
    public PrestamosActivos() {
        initComponents();
        txtBuscar.setText("(Buscar prestamo por Libro/Estudiante)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
        txtFechaActual.setEditable(false);
        txtFechaActual.setEnabled(false);
        listarPrestamosActivos();
    }

public void listarPrestamosActivos() {
    String filtro = txtBuscar.getText().trim();
    if (filtro.equals("(Buscar prestamo por Libro/Estudiante)")) {
        filtro = "";
    }
    java.util.List<Modelo.Prestamo> lista = controlPrestamo.obtenerPrestamosActivos(filtro);
    DefaultTableModel modelo = (DefaultTableModel) tablaPrestamosActivos.getModel();
    modelo.setRowCount(0);
    java.time.format.DateTimeFormatter formatoMySQL = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
    java.time.format.DateTimeFormatter formatoUI = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
    java.time.LocalDate hoy = java.time.LocalDate.now();
    
    // 🆕 Traemos la lista de estudiantes para mapear los IDs a nombres legibles
    Controlador.EstudianteController controlEstudiante = new Controlador.EstudianteController();
    java.util.List<Modelo.Estudiante> listaEstudiantes = controlEstudiante.obtenerTodos();
    
    Object[] fila = new Object[6];
    for (Modelo.Prestamo p : lista) {
        int codigo = p.getCodigoLibro();
        fila[0] = controlLibro.obtenerTituloPorCodigo(codigo); 

        String nombreEstudiante = "Desconocido (ID: " + p.getIdEstudiante() + ")";
        for (Modelo.Estudiante est : listaEstudiantes) {
            if (est.getId() == p.getIdEstudiante()) {
                nombreEstudiante = est.getNombre() + " " + est.getApellido();
                break;
            }
        }
        fila[1] = nombreEstudiante; 
        try {
            java.time.LocalDate fPrestamo = java.time.LocalDate.parse(p.getFechaPrestamo().trim(), formatoMySQL);
            java.time.LocalDate fLimite = java.time.LocalDate.parse(p.getFechaLimite().trim(), formatoMySQL);
            
            fila[2] = fPrestamo.format(formatoUI);
            fila[3] = fLimite.format(formatoUI);
            long diasRestantes = java.time.temporal.ChronoUnit.DAYS.between(hoy, fLimite);
            if (diasRestantes < 0) {
                fila[4] = "VENCIDO (" + Math.abs(diasRestantes) + " días)";
            } else if (diasRestantes == 0) {
                fila[4] = "ENTREGA HOY";
            } else {
                fila[4] = diasRestantes + " días restantes";
            }
        } catch (Exception e) {
            fila[2] = p.getFechaPrestamo();
            fila[3] = p.getFechaLimite();
            fila[4] = "Error formato";
        }
        
        fila[5] = p.getEstado(); 
        modelo.addRow(fila);
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPrestamosActivos = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtFechaActual = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        spDiasExtender = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 33, 640, 10));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Buscar:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 60, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 450, -1));

        tablaPrestamosActivos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Titulo del libro", "Estudiante", "Fecha de prestamo", "Fecha Limite", "Dias restantes", "Acciones"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaPrestamosActivos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPrestamosActivosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaPrestamosActivos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 640, 200));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Prestamos activos");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, -1, -1));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 640, 10));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Nueva fecha de devolucion");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 310, -1, -1));

        jLabel1.setText("Añadir dias:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 390, -1, -1));

        jLabel5.setText("Fecha limite:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, -1, -1));
        getContentPane().add(txtFechaActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 340, 160, -1));

        jButton1.setBackground(new java.awt.Color(244, 87, 54));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Cancelar");
        jButton1.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED)));
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 430, 140, 30));

        jButton2.setBackground(new java.awt.Color(117, 189, 107));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Confirmar renovacion");
        jButton2.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED)));
        jButton2.addActionListener(this::jButton2ActionPerformed);
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 430, 140, 30));

        spDiasExtender.setModel(new javax.swing.SpinnerNumberModel(1, 1, 90, 1));
        getContentPane().add(spDiasExtender, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 390, 160, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
listarPrestamosActivos();
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void tablaPrestamosActivosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPrestamosActivosMouseClicked
   int fila = tablaPrestamosActivos.getSelectedRow();
    if (fila != -1) {
        String filtro = txtBuscar.getText().trim();
        if (filtro.equals("(Buscar prestamo por Libro/Estudiante)") || filtro.equals("(Buscar prestamo por Libro/Estudiante)")) {
            filtro = "";
        }
        
        java.util.List<Modelo.Prestamo> lista = controlPrestamo.obtenerPrestamosActivos(filtro);
        if (lista == null || lista.isEmpty() || fila >= lista.size()) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Error de sincronización visual. Por favor, recargue o limpie el buscador.", 
                "Error de Índice", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        idPrestamoSeleccionado = lista.get(fila).getIdPrestamo();
        java.time.format.DateTimeFormatter formatoMySQL = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
        java.time.format.DateTimeFormatter formatoUI = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String fechaLimiteBD = lista.get(fila).getFechaLimite();
        
        try {
            if (fechaLimiteBD != null && !fechaLimiteBD.trim().isEmpty()) {
                java.time.LocalDate fechaLimObj = java.time.LocalDate.parse(fechaLimiteBD.trim(), formatoMySQL);
                txtFechaActual.setText(fechaLimObj.format(formatoUI));
            } else {
                txtFechaActual.setText("");
            }
        } catch (Exception e) {
            txtFechaActual.setText(fechaLimiteBD);
        }
        spDiasExtender.setValue(1); 
    }

    }//GEN-LAST:event_tablaPrestamosActivosMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
     if (idPrestamoSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione un préstamo activo de la tabla.");
        return;
    }
    int diasAExtender = (int) spDiasExtender.getValue(); 
    
    try {
        String filtro = txtBuscar.getText().trim();
        if (filtro.equals("(Buscar prestamo por Libro/Estudiante)")) filtro = "";
        Modelo.Prestamo prestamoActual = null;
        for (Modelo.Prestamo p : controlPrestamo.obtenerPrestamosActivos(filtro)) {
            if (p.getIdPrestamo() == idPrestamoSeleccionado) {
                prestamoActual = p;
                break;
            }
        }
        
        if (prestamoActual == null) return;
        java.time.format.DateTimeFormatter formatoMySQL = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
        java.time.LocalDate fechaLimiteOriginal = java.time.LocalDate.parse(prestamoActual.getFechaLimite().trim(), formatoMySQL);
        java.time.LocalDate nuevaFechaLimiteObj = fechaLimiteOriginal.plusDays(diasAExtender);
        String nuevaFechaLimMySQL = nuevaFechaLimiteObj.format(formatoMySQL);
        boolean exito = controlPrestamo.renovarPrestamo(idPrestamoSeleccionado, nuevaFechaLimMySQL);
        if (exito) {
            java.time.format.DateTimeFormatter formatoUI = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
            javax.swing.JOptionPane.showMessageDialog(this, "¡Préstamo renovado con éxito! Nueva fecha límite: " + nuevaFechaLimiteObj.format(formatoUI));
            idPrestamoSeleccionado = -1;
            txtFechaActual.setText("");
            spDiasExtender.setValue(1);
            listarPrestamosActivos(); 
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Error al renovar el préstamo en el sistema.", "Error", 0);
        }
        
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al procesar el cálculo de fechas.", "Error", 0);
    }



    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     txtFechaActual.setText(null);
     spDiasExtender.setValue(1);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained

    if (txtBuscar.getText().equals("(Buscar prestamo por Libro/Estudiante)")) {
        txtBuscar.setText("");
        txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
    }
    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
     if (txtBuscar.getText().trim().isEmpty()) {
        txtBuscar.setText("(Buscar prestamo por Libro/Estudiante)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153)); 
    }
    }//GEN-LAST:event_txtBuscarFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PrestamosActivos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSpinner spDiasExtender;
    private javax.swing.JTable tablaPrestamosActivos;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtFechaActual;
    // End of variables declaration//GEN-END:variables
}
