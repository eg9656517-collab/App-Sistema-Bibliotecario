
package Vista;

import Controlador.LibroController;
import javax.swing.table.DefaultTableModel;

public class HistorialPrestamos extends javax.swing.JFrame {
    private Controlador.PrestamoController controlPrestamo = new Controlador.PrestamoController();
    LibroController controlLibro = new LibroController();
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(HistorialPrestamos.class.getName());
    public HistorialPrestamos() {
        initComponents();
        this.setLocationRelativeTo(null);
        actualizarTablaHistorial();
        
    }
    
private void actualizarTablaHistorial() {
    DefaultTableModel modelo = (DefaultTableModel) tablaHistorial.getModel();
    modelo.setRowCount(0);
    
    String filtroEstudiante = txtBuscarEstudiante.getText().trim();
    String filtroLibro = txtBuscarLibro.getText().trim();
    String filtroFecha = txtBuscarFecha.getText().trim();
    String filtroEstado = cbEstadoFiltro.getSelectedItem() != null ? cbEstadoFiltro.getSelectedItem().toString().trim() : "";
    
    java.util.List<Modelo.Prestamo> listaPrestamos = controlPrestamo.filtrarHistorial(filtroEstudiante, filtroLibro, filtroFecha, filtroEstado);
    
    java.util.List<Modelo.Libro> listaLibros = controlLibro.obtenerTodos();
    Controlador.EstudianteController controlEstudiante = new Controlador.EstudianteController();
    java.util.List<Modelo.Estudiante> listaEstudiantes = controlEstudiante.obtenerTodos();
    Object[] fila = new Object[5];
    for (Modelo.Prestamo p : listaPrestamos) {
        String nombreEstudiante = "Desconocido (ID: " + p.getIdEstudiante() + ")";
        for (Modelo.Estudiante est : listaEstudiantes) {
            if (est.getId() == p.getIdEstudiante()) {
                nombreEstudiante = est.getNombre() + " " + est.getApellido();
                break;
            }
        }
        fila[0] = nombreEstudiante;
        String nombreLibro = "No encontrado";
        for (Modelo.Libro libro : listaLibros) {
            if (libro.getCodigo() == p.getCodigoLibro()) {
                nombreLibro = libro.getTitulo();
                break;
            }
        }
        fila[1] = nombreLibro;
        fila[2] = cambiarFormatoFecha(p.getFechaPrestamo());
        
        if (p.getFechaDevolucion() == null || p.getFechaDevolucion().trim().isEmpty() || p.getFechaDevolucion().equals("//")) {
            fila[3] = "---";
        } else {
            fila[3] = cambiarFormatoFecha(p.getFechaDevolucion());
        }
        
        fila[4] = p.getEstado(); 
        
        modelo.addRow(fila);
    }
}

private String cambiarFormatoFecha(String fechaMySQL) {
    if (fechaMySQL == null || fechaMySQL.trim().isEmpty()) return "---";
    try {
        java.time.format.DateTimeFormatter formatoMySQL = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
        java.time.format.DateTimeFormatter formatoUI = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return java.time.LocalDate.parse(fechaMySQL.trim(), formatoMySQL).format(formatoUI);
    } catch (Exception e) {
        return fechaMySQL;
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaHistorial = new javax.swing.JTable();
        txtBuscarFecha = new javax.swing.JTextField();
        txtBuscarEstudiante = new javax.swing.JTextField();
        txtBuscarLibro = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        btnRegresar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        cbEstadoFiltro = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Resultado de prestamo");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Historial de prestamo");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, -1));

        jLabel4.setText("Estudiante:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, -1));

        jLabel5.setText("Fecha de prestamo:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Filtros");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 143, 580, 10));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 33, 570, 10));

        tablaHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Estudiante", "Titulo de libro", "Fecha de prestamo", "Fecha de devolucion", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaHistorial);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 570, 220));

        txtBuscarFecha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarFechaKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscarFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 70, 120, -1));

        txtBuscarEstudiante.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarEstudianteKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscarEstudiante, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 110, -1));

        txtBuscarLibro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarLibroKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscarLibro, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 110, -1));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnRegresar.setBackground(new java.awt.Color(244, 67, 54));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(this::btnRegresarActionPerformed);
        jPanel1.add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 90, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 410, 570, 50));

        jLabel7.setText("Estado:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 110, -1, -1));

        cbEstadoFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "  ", "Activo", "Devuelto" }));
        cbEstadoFiltro.addActionListener(this::cbEstadoFiltroActionPerformed);
        getContentPane().add(cbEstadoFiltro, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 110, 120, -1));

        jLabel8.setText("Titulo del libro:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarEstudianteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarEstudianteKeyReleased
actualizarTablaHistorial();
    }//GEN-LAST:event_txtBuscarEstudianteKeyReleased

    private void txtBuscarLibroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarLibroKeyReleased
actualizarTablaHistorial();
    }//GEN-LAST:event_txtBuscarLibroKeyReleased

    private void txtBuscarFechaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarFechaKeyReleased
  actualizarTablaHistorial();
    }//GEN-LAST:event_txtBuscarFechaKeyReleased

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
this.dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void cbEstadoFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbEstadoFiltroActionPerformed
       actualizarTablaHistorial();
    }//GEN-LAST:event_cbEstadoFiltroActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new HistorialPrestamos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRegresar;
    private javax.swing.JComboBox<String> cbEstadoFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable tablaHistorial;
    private javax.swing.JTextField txtBuscarEstudiante;
    private javax.swing.JTextField txtBuscarFecha;
    private javax.swing.JTextField txtBuscarLibro;
    // End of variables declaration//GEN-END:variables
}
