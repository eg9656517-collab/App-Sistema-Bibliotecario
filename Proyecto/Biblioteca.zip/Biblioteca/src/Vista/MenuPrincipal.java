package Vista;

public class MenuPrincipal extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MenuPrincipal.class.getName());
    private String rolUsuario;
    public MenuPrincipal(String rol) {
        initComponents();
        this.setSize(1200, 750);
        this.setLocationRelativeTo(null);
        this.rolUsuario = rol;
        aplicarPermisosPorRol();
    }
   private void aplicarPermisosPorRol() {
    Modelo.Rol rolObjeto = Controlador.RolController.getRolActivo();
    
    String rol;
    if (rolObjeto != null) {
        rol = rolObjeto.getNombreRol();
    } else {
        rol = rolUsuario;
    }
    
    if (rol == null) {
        rol = "";
    }
    
    rol = rol.toUpperCase().trim();
    
    switch (rol) {
        case "ADMINISTRADOR":
            break;
            
        case "BIBLIOTECARIO":
            menuCrearUsuario.setVisible(false);
            menuEliminarUsuario.setVisible(false);
            menuConsultarUsuario.setVisible(false);
            menuGestionRoles.setVisible(false);
            break;
            
        default:
            javax.swing.JOptionPane.showMessageDialog(this, 
                "El rol '" + rol + "' no cuenta temporalmente con permisos para acceder al sistema.", 
                "Error de Seguridad", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
            this.dispose();
            break;
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jDesktopPane1 = new javax.swing.JDesktopPane() {
            private java.awt.Image imagenFondo = new javax.swing.ImageIcon(getClass().getResource("/imagenes/MenuPrincipal.jpg")).getImage();

            @Override
            protected void paintComponent(java.awt.Graphics g) {
                super.paintComponent(g);
                g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), this);
            }
        };
        jMenuBar1 = new javax.swing.JMenuBar();
        jmenuUsuario = new javax.swing.JMenu();
        menuCrearUsuario = new javax.swing.JMenuItem();
        menuEliminarUsuario = new javax.swing.JMenuItem();
        menuConsultarUsuario = new javax.swing.JMenuItem();
        menuRegistrarEstudiante = new javax.swing.JMenuItem();
        menuGestionRoles = new javax.swing.JMenuItem();
        jmenuLibros = new javax.swing.JMenu();
        menuRegistrarLibro = new javax.swing.JMenuItem();
        menuCategorias = new javax.swing.JMenuItem();
        MenuAutor = new javax.swing.JMenuItem();
        MenuEditorial = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        menuPrestamosActivos = new javax.swing.JMenuItem();
        menuRegistrarPrestamo = new javax.swing.JMenuItem();
        jMenuhistorialprestamos = new javax.swing.JMenuItem();
        jmenuReporte = new javax.swing.JMenu();
        menuReportes = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        MenuCerrarSeccion = new javax.swing.JMenuItem();

        jMenu1.setText("File");
        jMenuBar2.add(jMenu1);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jMenuItem2.setText("jMenuItem2");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setSize(new java.awt.Dimension(1200, 750));

        jDesktopPane1.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 686, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 580, Short.MAX_VALUE)
        );

        getContentPane().add(jDesktopPane1, java.awt.BorderLayout.CENTER);

        jmenuUsuario.setText("Usuarios");

        menuCrearUsuario.setText("Crear usuario");
        menuCrearUsuario.addActionListener(this::menuCrearUsuarioActionPerformed);
        jmenuUsuario.add(menuCrearUsuario);

        menuEliminarUsuario.setText("Eliminar usuario");
        menuEliminarUsuario.addActionListener(this::menuEliminarUsuarioActionPerformed);
        jmenuUsuario.add(menuEliminarUsuario);

        menuConsultarUsuario.setText("Consultar usuario");
        menuConsultarUsuario.addActionListener(this::menuConsultarUsuarioActionPerformed);
        jmenuUsuario.add(menuConsultarUsuario);

        menuRegistrarEstudiante.setText("Registrar Estudiante");
        menuRegistrarEstudiante.addActionListener(this::menuRegistrarEstudianteActionPerformed);
        jmenuUsuario.add(menuRegistrarEstudiante);

        menuGestionRoles.setText("Gestion de roles");
        menuGestionRoles.addActionListener(this::menuGestionRolesActionPerformed);
        jmenuUsuario.add(menuGestionRoles);

        jMenuBar1.add(jmenuUsuario);

        jmenuLibros.setText("Libros");

        menuRegistrarLibro.setText("Registrar Libro");
        menuRegistrarLibro.addActionListener(this::menuRegistrarLibroActionPerformed);
        jmenuLibros.add(menuRegistrarLibro);

        menuCategorias.setText("Registrar Categoria");
        menuCategorias.addActionListener(this::menuCategoriasActionPerformed);
        jmenuLibros.add(menuCategorias);

        MenuAutor.setText("Registrar Autor");
        MenuAutor.addActionListener(this::MenuAutorActionPerformed);
        jmenuLibros.add(MenuAutor);

        MenuEditorial.setText("Registrar Editorial");
        MenuEditorial.addActionListener(this::MenuEditorialActionPerformed);
        jmenuLibros.add(MenuEditorial);

        jMenuBar1.add(jmenuLibros);

        jMenu3.setText("Prestamos");

        menuPrestamosActivos.setText("Prestamos activos");
        menuPrestamosActivos.addActionListener(this::menuPrestamosActivosActionPerformed);
        jMenu3.add(menuPrestamosActivos);

        menuRegistrarPrestamo.setText("Registrar prestamo");
        menuRegistrarPrestamo.addActionListener(this::menuRegistrarPrestamoActionPerformed);
        jMenu3.add(menuRegistrarPrestamo);

        jMenuhistorialprestamos.setText("Historial de prestamo");
        jMenuhistorialprestamos.addActionListener(this::jMenuhistorialprestamosActionPerformed);
        jMenu3.add(jMenuhistorialprestamos);

        jMenuBar1.add(jMenu3);

        jmenuReporte.setText("Reporte");

        menuReportes.setText("Reportes");
        menuReportes.addActionListener(this::menuReportesActionPerformed);
        jmenuReporte.add(menuReportes);

        jMenuBar1.add(jmenuReporte);

        jMenu7.setText("Cerrar seccion");

        MenuCerrarSeccion.setText("Cerrar seccion");
        MenuCerrarSeccion.addActionListener(this::MenuCerrarSeccionActionPerformed);
        jMenu7.add(MenuCerrarSeccion);

        jMenuBar1.add(jMenu7);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuRegistrarLibroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRegistrarLibroActionPerformed
    abrirVentana(new RegistrarLibro());
    }//GEN-LAST:event_menuRegistrarLibroActionPerformed

    private void menuCrearUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCrearUsuarioActionPerformed
abrirVentana(new CrearUsuario());
    }//GEN-LAST:event_menuCrearUsuarioActionPerformed

    private void menuGestionRolesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuGestionRolesActionPerformed
   abrirVentana(new GestionRoles());
    }//GEN-LAST:event_menuGestionRolesActionPerformed

    private void menuRegistrarEstudianteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRegistrarEstudianteActionPerformed
abrirVentana(new RegistrarEstudiante());  
    }//GEN-LAST:event_menuRegistrarEstudianteActionPerformed

    private void menuConsultarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsultarUsuarioActionPerformed
abrirVentana(new ConsultarUsuario());
    }//GEN-LAST:event_menuConsultarUsuarioActionPerformed

    private void menuRegistrarPrestamoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRegistrarPrestamoActionPerformed
      abrirVentana(new RegistrarPrestamo());
    }//GEN-LAST:event_menuRegistrarPrestamoActionPerformed

    private void jMenuhistorialprestamosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuhistorialprestamosActionPerformed
    abrirVentana(new HistorialPrestamos());
    }//GEN-LAST:event_jMenuhistorialprestamosActionPerformed

    private void menuPrestamosActivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuPrestamosActivosActionPerformed
       abrirVentana(new PrestamosActivos());
    }//GEN-LAST:event_menuPrestamosActivosActionPerformed

    private void menuEliminarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEliminarUsuarioActionPerformed
       abrirVentana(new EliminarUsuario());
    }//GEN-LAST:event_menuEliminarUsuarioActionPerformed

    private void MenuCerrarSeccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuCerrarSeccionActionPerformed
int respuesta = javax.swing.JOptionPane.showConfirmDialog(
            this, 
            "¿Estás seguro de que deseas cerrar sesión?", 
            "Confirmar Salida", 
            javax.swing.JOptionPane.YES_NO_OPTION, 
            javax.swing.JOptionPane.QUESTION_MESSAGE
    );
    if (respuesta == javax.swing.JOptionPane.YES_OPTION) {
        Login login = new Login();
        login.setVisible(true);
        this.dispose(); 
    }
    }//GEN-LAST:event_MenuCerrarSeccionActionPerformed

    private void menuReportesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuReportesActionPerformed
  abrirInternalFrame(new ReportesForm());
    }//GEN-LAST:event_menuReportesActionPerformed

    private void menuCategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCategoriasActionPerformed
       abrirVentana(new CrearCategoria());
    }//GEN-LAST:event_menuCategoriasActionPerformed

    private void MenuAutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuAutorActionPerformed
        abrirDialogo(new RegistrarAutor(this, true));
    }//GEN-LAST:event_MenuAutorActionPerformed

    private void MenuEditorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuEditorialActionPerformed
        abrirDialogo(new RegistrarEditorial(this, true));
    }//GEN-LAST:event_MenuEditorialActionPerformed
private void abrirInternalFrame(javax.swing.JInternalFrame frame) {
  jDesktopPane1.add(frame, javax.swing.JLayeredPane.DEFAULT_LAYER);
    frame.setVisible(true);
    try {
        frame.setSelected(true);
    } catch (java.beans.PropertyVetoException e) {
        e.printStackTrace();
    }
}

    private void abrirVentana(javax.swing.JFrame ventana) {
    ventana.setVisible(true);
    ventana.setLocationRelativeTo(null); 
}
private void abrirDialogo(javax.swing.JDialog dialogo) {
    dialogo.setLocationRelativeTo(null);
    dialogo.setVisible(true);
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
java.awt.EventQueue.invokeLater(() -> { new MenuPrincipal("Administrador").setVisible(true);
    });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem MenuAutor;
    private javax.swing.JMenuItem MenuCerrarSeccion;
    private javax.swing.JMenuItem MenuEditorial;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem2;
    public javax.swing.JMenuItem jMenuhistorialprestamos;
    private javax.swing.JMenu jmenuLibros;
    private javax.swing.JMenu jmenuReporte;
    public javax.swing.JMenu jmenuUsuario;
    private javax.swing.JMenuItem menuCategorias;
    public javax.swing.JMenuItem menuConsultarUsuario;
    public javax.swing.JMenuItem menuCrearUsuario;
    public javax.swing.JMenuItem menuEliminarUsuario;
    public javax.swing.JMenuItem menuGestionRoles;
    public javax.swing.JMenuItem menuPrestamosActivos;
    public javax.swing.JMenuItem menuRegistrarEstudiante;
    public javax.swing.JMenuItem menuRegistrarLibro;
    public javax.swing.JMenuItem menuRegistrarPrestamo;
    private javax.swing.JMenuItem menuReportes;
    // End of variables declaration//GEN-END:variables
}
