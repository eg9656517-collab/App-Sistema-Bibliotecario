package Vista;


public class ReportesForm extends javax.swing.JInternalFrame {
    
    public ReportesForm() {
        initComponents();
         setClosable(true);
        setIconifiable(true);
    }
    
 public void actualizarReporteConFiltros(String tipoFiltro, String categoria, String seccion, java.util.Date fechaDesde, java.util.Date fechaHasta) {
    String textoMostrando = "Mostrando: " + tipoFiltro;
    
    if (fechaDesde != null && fechaHasta != null) {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
        textoMostrando += " (Desde: " + sdf.format(fechaDesde) + " Hasta: " + sdf.format(fechaHasta) + ")";
    } else if (fechaDesde != null) {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
        textoMostrando += " (Desde: " + sdf.format(fechaDesde) + ")";
    } else if (fechaHasta != null) {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
        textoMostrando += " (Hasta: " + sdf.format(fechaHasta) + ")";
    }
    Controlador.ReportePrestamoController controller = new Controlador.ReportePrestamoController();
    controller.cargarTablaReportes(tablaDetalle, tipoFiltro, categoria, seccion, fechaDesde, fechaHasta);
    controller.cargarGraficoReportes(panelGraficos, tipoFiltro, categoria, seccion, fechaDesde, fechaHasta);
}
 
 @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane2 = new javax.swing.JTabbedPane();
        panelGraficos = new javax.swing.JPanel();
        panelDetalle = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDetalle = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btnFiltros = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelGraficos.setBackground(new java.awt.Color(255, 255, 255));
        panelGraficos.setLayout(new java.awt.BorderLayout());
        jTabbedPane2.addTab("Grafico", panelGraficos);

        tablaDetalle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Selecciona un filtro para ver sus detalles y grafico"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaDetalle);

        javax.swing.GroupLayout panelDetalleLayout = new javax.swing.GroupLayout(panelDetalle);
        panelDetalle.setLayout(panelDetalleLayout);
        panelDetalleLayout.setHorizontalGroup(
            panelDetalleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDetalleLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 738, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelDetalleLayout.setVerticalGroup(
            panelDetalleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDetalleLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane2.addTab("Detalle", panelDetalle);

        getContentPane().add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 750, 440));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnFiltros.setText("Filtros");
        btnFiltros.addActionListener(this::btnFiltrosActionPerformed);
        jPanel1.add(btnFiltros, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 60));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jButton1.setText("Exportar pdf");

        jButton2.setText("Exportar excel");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(525, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 530, 750, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFiltrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiltrosActionPerformed
 FiltrosReporteForm filtrosForm = new FiltrosReporteForm(this);
    javax.swing.JDesktopPane desktopPane = this.getDesktopPane();
    if (desktopPane != null) {
        desktopPane.add(filtrosForm);
        
        
        int x = (desktopPane.getWidth() - filtrosForm.getWidth()) / 2;
        int y = (desktopPane.getHeight() - filtrosForm.getHeight()) / 2;
        filtrosForm.setLocation(x, y);
        
        filtrosForm.setVisible(true);
        filtrosForm.toFront();
    }

    }//GEN-LAST:event_btnFiltrosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFiltros;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JPanel panelDetalle;
    private javax.swing.JPanel panelGraficos;
    private javax.swing.JTable tablaDetalle;
    // End of variables declaration//GEN-END:variables
}
