
package Vista;

public class CrearCategoria extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CrearCategoria.class.getName());
    Controlador.CategoriaController controlcat = new Controlador.CategoriaController();
    private int idSeleccionado = -1;
    public CrearCategoria() {
        initComponents();
        llenarTabla("");
        txtBuscar.setText("(Buscar Categoria por su nombre)");
         txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }
    private void limpiarFormulario() {
    txtNombreCategoria.setText("");
    txtDescripcion.setText("");
    if(txtBuscar != null) txtBuscar.setText("");
    idSeleccionado = -1;
    btnGuardar.setEnabled(true);
    llenarTabla("");
     txtBuscar.setText("(Buscar Categoria por su nombre)");
}
public void llenarTabla(String texto) {
    javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) tablaCategorias.getModel();
    modelo.setRowCount(0);
    java.util.List<Modelo.Categoria> lista = controlcat.obtenerCategorias();
    
    Object[] fila = new Object[3];
    for (Modelo.Categoria c : lista) {
        if (c.getNombre().toLowerCase().contains(texto.toLowerCase())) {
            fila[0] = c.getId_categoria();
            fila[1] = c.getNombre();
            fila[2] = c.getDescripcion();
            modelo.addRow(fila);
        }
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        txtNombreCategoria = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCategorias = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Nombre categoria:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel2.setText("Descripcion:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, -1, -1));
        getContentPane().add(txtDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 310, 30));
        getContentPane().add(txtNombreCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 170, -1));

        tablaCategorias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID Categoria", "Nombre", "Descripcion"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaCategorias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaCategoriasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaCategorias);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 510, 240));

        jButton1.setBackground(new java.awt.Color(73, 144, 180));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Actualizar");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 480, -1, -1));

        btnGuardar.setBackground(new java.awt.Color(117, 189, 107));
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, -1, -1));

        jButton3.setBackground(new java.awt.Color(244, 87, 54));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Eliminar");
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 480, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Registrar Categoria");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 350, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 240, -1));

        jButton4.setBackground(new java.awt.Color(153, 153, 153));
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Limpiar");
        jButton4.addActionListener(this::jButton4ActionPerformed);
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 480, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
    String nombre = txtNombreCategoria.getText().trim();
    String descripcion = txtDescripcion.getText().trim();

    if (nombre.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "El nombre es requerido.");
        txtNombreCategoria.requestFocus();
        return;
    }
    
    if (descripcion.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "La descripción es requerida.");
        txtDescripcion.requestFocus();
        return;
    }
    if (controlcat.existeNombreCategoria(nombre, -1)) {
        javax.swing.JOptionPane.showMessageDialog(this, "Ya existe una categoría registrada con el nombre: " + nombre, "Categoría Duplicada", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtNombreCategoria.requestFocus();
        return;
    }

    if (controlcat.registrarCategoria(nombre, descripcion)) {
        javax.swing.JOptionPane.showMessageDialog(this, "Categoría guardada exitosamente.");
        limpiarFormulario();
        llenarTabla("");
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar la categoría.");
    }

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void tablaCategoriasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaCategoriasMouseClicked
      int filaSeleccionada = tablaCategorias.getSelectedRow();
    
    if (filaSeleccionada >= 0) {
        idSeleccionado = Integer.parseInt(tablaCategorias.getValueAt(filaSeleccionada, 0).toString());
        txtNombreCategoria.setText(tablaCategorias.getValueAt(filaSeleccionada, 1).toString());
        txtDescripcion.setText(tablaCategorias.getValueAt(filaSeleccionada, 2).toString());
        btnGuardar.setEnabled(false);
    }
    }//GEN-LAST:event_tablaCategoriasMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    if (idSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione una categoría de la tabla.");
        return;
    }

    String nombre = txtNombreCategoria.getText().trim();
    String descripcion = txtDescripcion.getText().trim();

    if (nombre.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "El nombre de la categoría no puede estar vacío.");
        txtNombreCategoria.requestFocus();
        return;
    }
    
    if (descripcion.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "La descripción no puede estar vacía.");
        txtDescripcion.requestFocus();
        return;
    }

    if (controlcat.existeNombreCategoria(nombre, idSeleccionado)) {
        javax.swing.JOptionPane.showMessageDialog(this, "Ya existe otra categoría registrada con el nombre: " + nombre, "Categoría Duplicada", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtNombreCategoria.requestFocus();
        return;
    }

    if (controlcat.modificarCategoria(idSeleccionado, nombre, descripcion)) {
        javax.swing.JOptionPane.showMessageDialog(this, "Categoría actualizada con éxito.");
        limpiarFormulario();
        llenarTabla("");
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al actualizar la categoría.");
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       if (idSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione una categoría de la tabla.");
        return;
    }
    
    int respuesta = javax.swing.JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de eliminar esta categoría?", "Confirmar Eliminación", javax.swing.JOptionPane.YES_NO_OPTION);
            
    if (respuesta == javax.swing.JOptionPane.YES_OPTION) {
        if (controlcat.eliminarCategoria(idSeleccionado)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Categoría eliminada con éxito.");
            limpiarFormulario();
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Error al eliminar la categoría.");
        }
    }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
      llenarTabla(txtBuscar.getText().trim());
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained
       if (txtBuscar.getText().equals("(Buscar Categoria por su nombre)")) {
        txtBuscar.setText("");
        txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
    }
    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
      if (txtBuscar.getText().trim().isEmpty()) {
        txtBuscar.setText("(Buscar Categoria por su nombre)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }
    }//GEN-LAST:event_txtBuscarFocusLost

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       limpiarFormulario();
    }//GEN-LAST:event_jButton4ActionPerformed

    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new CrearCategoria().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaCategorias;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtNombreCategoria;
    // End of variables declaration//GEN-END:variables
}
