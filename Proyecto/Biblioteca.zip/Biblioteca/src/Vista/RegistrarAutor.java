package Vista;

public class RegistrarAutor extends javax.swing.JDialog {
    private RegistrarLibro ventanaLibro;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(RegistrarAutor.class.getName());
private int idSeleccionado = -1;
    public RegistrarAutor(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        if (parent instanceof RegistrarLibro){this.ventanaLibro = (RegistrarLibro) parent;}
        llenarTabla("");
        txtBuscar.setText("(Buscar Autor)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }

  public void llenarTabla(String texto) {
    javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) tablaAutores.getModel();
    modelo.setRowCount(0); 
    Controlador.AutorController controlAut = new Controlador.AutorController();
 
    for (Modelo.Autor a : controlAut.obtenerAutores()) {
        if (a.getNombre().toLowerCase().contains(texto.toLowerCase()) || 
            a.getApellido().toLowerCase().contains(texto.toLowerCase())) {
            
            modelo.addRow(new Object[]{
                a.getId_autor(), 
                a.getNombre(), 
                a.getApellido()
            });
        }
    }
}
   private void limpiarFormulario() {
    txtNombreAutor.setText("");
    txtApellido.setText("");
    if(txtBuscar != null) txtBuscar.setText("");
    idSeleccionado = -1;
    btnGuardar.setEnabled(true);
    llenarTabla("");
     txtBuscar.setText("(Buscar Autor)");
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaAutores = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        txtNombreAutor = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Registrar Autor");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, 320, -1));

        tablaAutores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID_autor", "Nombre", "Apellido"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaAutores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaAutoresMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaAutores);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 450, 250));

        jLabel2.setText("Nombre:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        jLabel3.setText("Apellido:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 300, -1));
        getContentPane().add(txtNombreAutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 160, -1));
        getContentPane().add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 160, -1));

        btnGuardar.setBackground(new java.awt.Color(117, 189, 107));
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, -1, -1));

        btnActualizar.setBackground(new java.awt.Color(73, 144, 180));
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(this::btnActualizarActionPerformed);
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 460, -1, -1));

        btnEliminar.setBackground(new java.awt.Color(244, 87, 54));
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, -1, -1));

        btnLimpiar.setBackground(new java.awt.Color(153, 153, 153));
        btnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(this::btnLimpiarActionPerformed);
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 460, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
String nombre = txtNombreAutor.getText().trim();
    String apellido = txtApellido.getText().trim();

    if (nombre.isEmpty() || apellido.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Por favor, complete tanto el nombre como el apellido.", 
                "Campos Vacíos", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    Controlador.AutorController controlAut = new Controlador.AutorController();

    if (controlAut.existeAutor(nombre, apellido, -1)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "El autor '" + nombre + " " + apellido + "' ya se encuentra registrado.", 
                "Autor Duplicado", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
        txtNombreAutor.requestFocus();
        return;
    }

    if (controlAut.registrarAutor(nombre, apellido)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Autor registrado con éxito.", 
                "Éxito", 
                javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
        txtNombreAutor.setText("");
        txtApellido.setText("");
        if (txtBuscar != null) txtBuscar.setText(""); 
        
        llenarTabla(""); 
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Error al guardar el autor en la base de datos.", 
                "Error", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }


    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
int filaSeleccionada = tablaAutores.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Seleccione un autor de la tabla para actualizar.", 
                "Advertencia", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    String nombre = txtNombreAutor.getText().trim();
    String apellido = txtApellido.getText().trim();

    if (nombre.isEmpty() || apellido.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Por favor, complete todos los campos.", 
                "Advertencia", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    int idAutor = Integer.parseInt(tablaAutores.getValueAt(filaSeleccionada, 0).toString());
    Controlador.AutorController controlAut = new Controlador.AutorController();

    if (controlAut.existeAutor(nombre, apellido, idAutor)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Ya existe otro autor registrado como '" + nombre + " " + apellido + "'.", 
                "Autor Duplicado", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
        txtNombreAutor.requestFocus();
        return;
    }

    if (controlAut.modificarAutor(idAutor, nombre, apellido)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Autor actualizado correctamente.", 
                "Éxito", 
                javax.swing.JOptionPane.INFORMATION_MESSAGE);
        llenarTabla("");
        limpiarFormulario();
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Error al registrar el autor", 
                "Error", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
int filaSeleccionada = tablaAutores.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione un autor de la tabla para eliminar.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }   
    int idAutor = Integer.parseInt(tablaAutores.getValueAt(filaSeleccionada, 0).toString());
    String nombreCompleto = tablaAutores.getValueAt(filaSeleccionada, 1).toString() + " " + tablaAutores.getValueAt(filaSeleccionada, 2).toString();
    int confirmar = javax.swing.JOptionPane.showConfirmDialog(
        this, 
        "¿Está seguro de que desea eliminar al autor '" + nombreCompleto + "'?", 
        "Confirmar Eliminación", 
        javax.swing.JOptionPane.YES_NO_OPTION
    );
    
    if (confirmar == javax.swing.JOptionPane.YES_OPTION) {
        Controlador.AutorController controlAut = new Controlador.AutorController();
        
        if (controlAut.eliminarAutor(idAutor)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Autor eliminado correctamente.", "Éxito", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            llenarTabla("");
            limpiarFormulario();
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Error al eliminar el autor. Verifique si está asignado a un libro activo.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
   limpiarFormulario();     
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void tablaAutoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaAutoresMouseClicked
       int filaSeleccionada = tablaAutores.getSelectedRow();
    if (filaSeleccionada != -1) {
        if (evt.getClickCount() == 2) {
            String nombre = tablaAutores.getValueAt(filaSeleccionada, 1).toString();
            String apellido = tablaAutores.getValueAt(filaSeleccionada, 2).toString();
            String nombreCompleto = nombre + " " + apellido;
            
            if (ventanaLibro != null) {
                ventanaLibro.txtAutor.setText(nombreCompleto);
                this.dispose();
            }
        } 
        else if (evt.getClickCount() == 1) {
            String nombre = tablaAutores.getValueAt(filaSeleccionada, 1).toString();
            String apellido = tablaAutores.getValueAt(filaSeleccionada, 2).toString();
            txtNombreAutor.setText(nombre);
            txtApellido.setText(apellido);
        }
    }

    }//GEN-LAST:event_tablaAutoresMouseClicked

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
       llenarTabla(txtBuscar.getText().trim());

    }//GEN-LAST:event_txtBuscarKeyReleased

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained
         if (txtBuscar.getText().equals("(Buscar Autor)")) {
        txtBuscar.setText("");
        txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
    }
    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
       if (txtBuscar.getText().trim().isEmpty()) {
        txtBuscar.setText("(Buscar Autor)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }
    }//GEN-LAST:event_txtBuscarFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                RegistrarAutor dialog = new RegistrarAutor(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaAutores;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtNombreAutor;
    // End of variables declaration//GEN-END:variables
}
