package Vista;

import Controlador.LibroController;
import javax.swing.table.DefaultTableModel;

public class RegistrarPrestamo extends javax.swing.JFrame {
   private Controlador.PrestamoController controlPrestamo = new Controlador.PrestamoController();
private int idPrestamoSeleccionado = -1;
LibroController controlLibro = new LibroController();
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(RegistrarPrestamo.class.getName());
     
    public RegistrarPrestamo() {
    initComponents();
    txtBuscar.setText("(Buscar prestamo por Estado/Titulo)");
    txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    txtIdPrestamo.setEditable(false);
    txtIdPrestamo.setEnabled(false);
    btnRegistrarDevolucion.setEnabled(false); 
    txtFechaPrestamo.setEditable(false);
    txtFechaPrestamo.setEnabled(false);
    java.time.LocalDate hoy = java.time.LocalDate.now();
    java.time.format.DateTimeFormatter formato = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
     txtFechaPrestamo.setText("");
    listarPrestamos();
}
 public void actualizarStockInformativo() {
    String titulo = txtTituloLibro.getText().trim();
    if (!titulo.isEmpty()) {
        Controlador.LibroController controlLibro = new Controlador.LibroController();
        int stock = controlLibro.obtenerStockPorTitulo(titulo);
        
        if (stock == -1) {
            lblStockInformativo.setText("Libro no registrado");
            lblStockInformativo.setForeground(java.awt.Color.ORANGE);
        } else if (stock == 0) {
            lblStockInformativo.setText("Unidades agotadas");
            lblStockInformativo.setForeground(java.awt.Color.RED);
        } else {
            lblStockInformativo.setText("Disponible (" + stock + " unidades)");
            lblStockInformativo.setForeground(new java.awt.Color(0, 153, 51));
        }
    } else {
        lblStockInformativo.setText("Stock disponible: --");
        lblStockInformativo.setForeground(java.awt.Color.BLACK);
    }
}  

public void limpiarCampos() {
    txtIdPrestamo.setText("");
    txtIdEstudiante.setText("");
    txtTituloLibro.setText(""); 
    lblStockInformativo.setText("Stock disponible: --");
    lblStockInformativo.setForeground(java.awt.Color.BLACK);
    txtFechaPrestamo.setText(null);
    txtFechaLimite.setText(null);
    cbxEstado.setSelectedIndex(0);
    txtBuscar.setText("");
    
    java.time.LocalDate hoy = java.time.LocalDate.now();
    java.time.format.DateTimeFormatter formato = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
    txtFechaPrestamo.setText(hoy.format(formato));
    txtBuscar.setText("(Buscar prestamo por Estado/Titulo)");
    txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    txtIdEstudiante.setEnabled(true);
        txtIdEstudiante.setEditable(true);
        txtTituloLibro.setEnabled(true);
        txtTituloLibro.setEditable(true);
        txtFechaLimite.setEditable(true);
        txtFechaLimite.setEnabled(true);
          buscarestudiante.setEnabled(true);
        buscarlibro.setEnabled(true);
        btnGuardar.setEnabled(true);
}
private void listarPrestamos() {
    Controlador.LibroController controlLibro = new Controlador.LibroController();
    Controlador.PrestamoController controlPrestamo = new Controlador.PrestamoController();
    Controlador.EstudianteController controlEstudiante = new Controlador.EstudianteController();
    java.util.List<Modelo.Estudiante> listaEstudiantes = controlEstudiante.obtenerTodos();
    
    javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) tablaPrestamos.getModel();
    modelo.setRowCount(0); 

    java.util.List<Modelo.Prestamo> lista = controlPrestamo.obtenerTodos();
    
    for (Modelo.Prestamo p : lista) {
        String tituloLibro = controlLibro.obtenerTituloPorCodigo(p.getCodigoLibro());
        if (tituloLibro == null || tituloLibro.isEmpty()) {
            tituloLibro = "ID: " + p.getCodigoLibro();
        }
        String nombreEstudiante = "Desconocido (ID: " + p.getIdEstudiante() + ")";
        for (Modelo.Estudiante est : listaEstudiantes) {
            if (est.getId() == p.getIdEstudiante()) {
                nombreEstudiante = est.getNombre() + " " + est.getApellido();
                break;
            }
        }

        Object[] objeto = new Object[7];
        objeto[0] = p.getIdPrestamo();
        objeto[1] = nombreEstudiante;
        objeto[2] = tituloLibro; 
        objeto[3] = p.getFechaPrestamo();
        objeto[4] = p.getFechaLimite();
        objeto[5] = p.getFechaDevolucion();
        objeto[6] = p.getEstado();
        
        modelo.addRow(objeto);
    }
}
public void restablecerFormulario() {
    limpiarCampos();
    listarPrestamos();
    idPrestamoSeleccionado = -1;
    tablaPrestamos.clearSelection(); 
    btnGuardar.setEnabled(true);
    btnRegistrarDevolucion.setEnabled(false); 
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtIdPrestamo = new javax.swing.JTextField();
        txtIdEstudiante = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtTituloLibro = new javax.swing.JTextField();
        txtBuscar = new javax.swing.JTextField();
        btnRegistrarDevolucion = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPrestamos = new javax.swing.JTable();
        cbxEstado = new javax.swing.JComboBox<>();
        txtFechaPrestamo = new javax.swing.JFormattedTextField();
        txtFechaLimite = new javax.swing.JFormattedTextField();
        btnEliminar = new javax.swing.JButton();
        lblStockInformativo = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        buscarlibro = new javax.swing.JButton();
        buscarestudiante = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 50, 40));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Registrar Prestamos-Devoluciones");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, -1, -1));

        jLabel3.setText("ID prestamo:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, -1, -1));

        jLabel4.setText("Estudiante:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, -1, 20));

        jLabel5.setText("Fecha de Prestamo:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 70, -1, -1));

        jLabel6.setText("Fecha Limite:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 100, -1, -1));

        jLabel7.setText("Estado:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 130, 50, 20));
        getContentPane().add(txtIdPrestamo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 120, -1));
        getContentPane().add(txtIdEstudiante, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 120, -1));

        jLabel8.setText("TItulo libro:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, -1, -1));

        txtTituloLibro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTituloLibroFocusLost(evt);
            }
        });
        txtTituloLibro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTituloLibroKeyReleased(evt);
            }
        });
        getContentPane().add(txtTituloLibro, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 120, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addActionListener(this::txtBuscarActionPerformed);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 260, -1));

        btnRegistrarDevolucion.setBackground(new java.awt.Color(73, 144, 180));
        btnRegistrarDevolucion.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegistrarDevolucion.setForeground(new java.awt.Color(255, 255, 255));
        btnRegistrarDevolucion.setText("Registrar devolucion");
        btnRegistrarDevolucion.addActionListener(this::btnRegistrarDevolucionActionPerformed);
        getContentPane().add(btnRegistrarDevolucion, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 510, 150, -1));

        btnCancelar.setBackground(new java.awt.Color(153, 153, 153));
        btnCancelar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelar.setText("Limpiar");
        btnCancelar.addActionListener(this::btnCancelarActionPerformed);
        getContentPane().add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 510, 90, -1));

        btnGuardar.setBackground(new java.awt.Color(117, 189, 107));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 510, 110, 30));

        tablaPrestamos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Prestamo", "Estudiante", "Nombre del libro", "Fecha Prest.", "Fecha Limite", "Fecha devol.", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaPrestamos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPrestamosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaPrestamos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 680, 230));

        cbxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Devuelto" }));
        getContentPane().add(cbxEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 130, 140, -1));

        try {
            txtFechaPrestamo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        getContentPane().add(txtFechaPrestamo, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 70, 140, -1));

        try {
            txtFechaLimite.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        getContentPane().add(txtFechaLimite, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 100, 140, -1));

        btnEliminar.setBackground(new java.awt.Color(254, 67, 54));
        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 510, 110, -1));

        lblStockInformativo.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblStockInformativo.setText("Stock disponible: --");
        getContentPane().add(lblStockInformativo, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, 250, -1));
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 11, 50, 40));

        buscarlibro.setText("...");
        buscarlibro.addActionListener(this::buscarlibroActionPerformed);
        getContentPane().add(buscarlibro, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, -1, -1));

        buscarestudiante.setText("...");
        buscarestudiante.addActionListener(this::buscarestudianteActionPerformed);
        getContentPane().add(buscarestudiante, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
restablecerFormulario();
 txtFechaPrestamo.setText(null);
 txtFechaLimite.setText(null);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void tablaPrestamosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPrestamosMouseClicked
int filaSeleccionada = tablaPrestamos.getSelectedRow();
    if (filaSeleccionada != -1) {
        idPrestamoSeleccionado = Integer.parseInt(tablaPrestamos.getValueAt(filaSeleccionada, 0).toString());
        txtIdPrestamo.setText(String.valueOf(idPrestamoSeleccionado));
        String nombreEstudianteTabla = tablaPrestamos.getValueAt(filaSeleccionada, 1).toString();
        txtIdEstudiante.setText(nombreEstudianteTabla);
        
        String tituloLibro = tablaPrestamos.getValueAt(filaSeleccionada, 2).toString();
        txtTituloLibro.setText(tituloLibro);
        cbxEstado.setSelectedItem(tablaPrestamos.getValueAt(filaSeleccionada, 6).toString());
        
        if (tituloLibro != null && !tituloLibro.trim().isEmpty()) {
            Controlador.LibroController controlLibro = new Controlador.LibroController();
            int stock = controlLibro.obtenerStockPorTitulo(tituloLibro);
            
            if (stock == -1) {
                lblStockInformativo.setText("Libro no registrado");
                lblStockInformativo.setForeground(java.awt.Color.ORANGE);
            } else if (stock == 0) {
                lblStockInformativo.setText("Unidades agotadas");
                lblStockInformativo.setForeground(java.awt.Color.RED);
            } else {
                lblStockInformativo.setText("Disponible (" + stock + " unidades)");
                lblStockInformativo.setForeground(new java.awt.Color(0, 153, 51));
            }
        } else {
            lblStockInformativo.setText("Stock disponible: --");
            lblStockInformativo.setForeground(java.awt.Color.BLACK);
        }

        java.time.format.DateTimeFormatter formatoMySQL = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
        java.time.format.DateTimeFormatter formatoUI = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
        Object celdaFechaPres = tablaPrestamos.getValueAt(filaSeleccionada, 3);
        if (celdaFechaPres != null && !celdaFechaPres.toString().trim().isEmpty() && !celdaFechaPres.toString().equals("//")) {
            String fechaPresMySQL = celdaFechaPres.toString().trim();
            String fechaPresUI = java.time.LocalDate.parse(fechaPresMySQL, formatoMySQL).format(formatoUI);
            txtFechaPrestamo.setText(fechaPresUI);
        } else {
            txtFechaPrestamo.setText(""); 
        }
        
        Object celdaFechaLim = tablaPrestamos.getValueAt(filaSeleccionada, 4);
        if (celdaFechaLim != null && !celdaFechaLim.toString().trim().isEmpty()) {
            String fechaLimMySQL = celdaFechaLim.toString().trim();
            try {
                String fechaLimUI = java.time.LocalDate.parse(fechaLimMySQL, formatoMySQL).format(formatoUI);
                txtFechaLimite.setText(fechaLimUI);
            } catch (java.time.format.DateTimeParseException e) {
                txtFechaLimite.setText(""); 
            }
        } else {
            txtFechaLimite.setText("");
        }
 
        btnRegistrarDevolucion.setEnabled(true);
        txtIdEstudiante.setEnabled(false);
        txtIdEstudiante.setEditable(false);
        txtTituloLibro.setEnabled(false);
        txtTituloLibro.setEditable(false);
        cbxEstado.setEnabled(false);
        txtFechaLimite.setEditable(false);
        txtFechaLimite.setEnabled(false);
        buscarestudiante.setEnabled(false);
        buscarlibro.setEnabled(false);
          btnGuardar.setEnabled(false);
    }


    }//GEN-LAST:event_tablaPrestamosMouseClicked

    private void btnRegistrarDevolucionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarDevolucionActionPerformed
 if (idPrestamoSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione un préstamo activo de la tabla.");
        return;
    }
    int confirmar = javax.swing.JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de registrar esta devolución?", 
            "Confirmar Devolución", 
            javax.swing.JOptionPane.YES_NO_OPTION, 
            javax.swing.JOptionPane.QUESTION_MESSAGE);

    if (confirmar == javax.swing.JOptionPane.YES_OPTION) {
        try {
            java.time.LocalDate fechaActual = java.time.LocalDate.now();
            java.time.format.DateTimeFormatter formatoUI = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
            java.time.format.DateTimeFormatter formatoMySQL = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String fechaAutomaticaMySQL = fechaActual.format(formatoMySQL);
            String fechaLimiteStr = txtFechaLimite.getText().trim();
            java.time.LocalDate fechaLimiteObj = null;
            
            if (fechaLimiteStr.contains("-")) {
                fechaLimiteObj = java.time.LocalDate.parse(fechaLimiteStr, formatoMySQL);
            } else {
                fechaLimiteObj = java.time.LocalDate.parse(fechaLimiteStr, formatoUI);
            }
            
            if (fechaActual.isAfter(fechaLimiteObj)) {
                long diasDeRetraso = java.time.temporal.ChronoUnit.DAYS.between(fechaLimiteObj, fechaActual);
                String fechaLimiteLegible = fechaLimiteObj.format(formatoUI);
                
                javax.swing.JOptionPane.showMessageDialog(this, 
                    "ALERTA: Devolución con retraso\n" +
                    "El límite era el " + fechaLimiteLegible + ".\n" +
                    "Días de retraso: " + diasDeRetraso + " días.\n\n" +
                    "NOTE: El libro será registrado como 'Devuelto' y quedará disponible en el catálogo,\n" +
                    "A continuacion proceda a aplicar la multa correspondiente al estudiante en caja.", 
                    "Entrega Tardía",
                    javax.swing.JOptionPane.WARNING_MESSAGE);
            }
            
            if (controlPrestamo.procesarDevolucion(idPrestamoSeleccionado, fechaAutomaticaMySQL)) {
                javax.swing.JOptionPane.showMessageDialog(this, "Devolución exitosa. El inventario de este libro ha sido restaurado en el catálogo.");
                
                restablecerFormulario(); 
                
                txtFechaPrestamo.setText(null);
                txtFechaLimite.setText(null);
            } else {
                javax.swing.JOptionPane.showMessageDialog(this, "No se pudo actualizar el estado del préstamo. Revise que el libro no este devuelto.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (java.time.format.DateTimeParseException e) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Error: No se pudo procesar la fecha de límite [" + txtFechaLimite.getText() + "].", 
                "Formato Inválido", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
        }
        
        txtIdEstudiante.setEnabled(true);
        txtIdEstudiante.setEditable(true);
        txtTituloLibro.setEnabled(true);
        txtTituloLibro.setEditable(true);
        cbxEstado.setEnabled(true);
        txtFechaLimite.setEditable(true);
        txtFechaLimite.setEnabled(true);
    }

    }//GEN-LAST:event_btnRegistrarDevolucionActionPerformed

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
String texto = txtBuscar.getText().trim();
    java.util.List<Modelo.Prestamo> filtrada = controlPrestamo.buscarPrestamos(texto);
    DefaultTableModel modelo = (DefaultTableModel) tablaPrestamos.getModel();
    modelo.setRowCount(0);
    Controlador.LibroController controlLibro = new Controlador.LibroController();
    java.util.List<Modelo.Libro> listaLibros = controlLibro.obtenerTodos();
    Controlador.EstudianteController controlEstudiante = new Controlador.EstudianteController();
    java.util.List<Modelo.Estudiante> listaEstudiantes = controlEstudiante.obtenerTodos();
    
    Object[] fila = new Object[7]; 
    
    for (Modelo.Prestamo p : filtrada) {
        fila[0] = p.getIdPrestamo();
        String nombreEstudiante = "Desconocido (ID: " + p.getIdEstudiante() + ")";
        for (Modelo.Estudiante est : listaEstudiantes) {
            if (est.getId() == p.getIdEstudiante()) {
                nombreEstudiante = est.getNombre() + " " + est.getApellido();
                break;
            }
        }
        fila[1] = nombreEstudiante;
        String nombreLibro = "No encontrado";
        for (Modelo.Libro libro : listaLibros) {
            if (libro.getCodigo() == p.getCodigoLibro()) {
                nombreLibro = libro.getTitulo();
                break;
            }
        }

        fila[2] = nombreLibro; 
        fila[3] = p.getFechaPrestamo();
        fila[4] = p.getFechaLimite();
        fila[5] = (p.getFechaDevolucion() == null || p.getFechaDevolucion().isEmpty()) ? "---" : p.getFechaDevolucion(); 
        fila[6] = p.getEstado();
        
        modelo.addRow(fila);
    }

    }//GEN-LAST:event_txtBuscarKeyReleased

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
try {
        String nombreIngresado = txtIdEstudiante.getText().trim();
        if (nombreIngresado.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Por favor, ingrese el nombre del estudiante.");
            return;
        }
        
        Controlador.EstudianteController controlEstudiante = new Controlador.EstudianteController();
        int idEstudiante = -1;
        
        for (Modelo.Estudiante est : controlEstudiante.obtenerTodos()) {
            String nombreCompleto = est.getNombre() + " " + est.getApellido();
            if (nombreCompleto.equalsIgnoreCase(nombreIngresado) || est.getNombre().equalsIgnoreCase(nombreIngresado)) {
                idEstudiante = est.getId();
                break;
            }
        }
        
        if (idEstudiante == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "El estudiante '" + nombreIngresado + "' no se encuentra registrado en el sistema.", 
                "Estudiante no encontrado", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        String tituloIngresado = txtTituloLibro.getText().trim();
        if (tituloIngresado.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Por favor, ingrese el título del libro.");
            return;
        }
        
        java.time.format.DateTimeFormatter formatoMySQL = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
        java.time.LocalDate fechaActual = java.time.LocalDate.now();
        String fechaPres = fechaActual.format(formatoMySQL); 
        
        String fechaLimRaw = txtFechaLimite.getText().trim();
        if (fechaLimRaw.equals("/ /") || fechaLimRaw.replace(" ", "").equals("//")) {
            javax.swing.JOptionPane.showMessageDialog(this, "Por favor, complete el campo de Fecha Límite.");
            return;
        }
        
        java.time.format.DateTimeFormatter formatoUI = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
        java.time.LocalDate fechaLimiteObj = java.time.LocalDate.parse(fechaLimRaw, formatoUI);
        
        if (fechaLimiteObj.isBefore(fechaActual) || fechaLimiteObj.isEqual(fechaActual)) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "La Fecha Límite debe ser posterior al día de hoy.", 
                "Fecha Inválida", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
            return; 
        }
        
        String fechaLim = fechaLimiteObj.format(formatoMySQL);
        Controlador.LibroController controlLibro = new Controlador.LibroController();
        Modelo.Libro libroEncontrado = null;
        
        for (Modelo.Libro l : controlLibro.obtenerTodos()) {
            if (l.getTitulo().equalsIgnoreCase(tituloIngresado)) {
                libroEncontrado = l;
                break;
            }
        }
        
        if (libroEncontrado == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "El libro ingresado no se encuentra en el catalogo.");
            return;
        }
        
        int idLibroReal = libroEncontrado.getCodigo();

        if (controlPrestamo.tienePrestamoActivo(idEstudiante, idLibroReal)) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "El estudiante '" + nombreIngresado + "' ya tiene un préstamo activo de este mismo libro.", 
                "Préstamo Duplicado", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        String resultado = controlPrestamo.registrarPrestamo(idEstudiante, idLibroReal, fechaPres, fechaLim);
        
        if (resultado.equals("OK")) {
            if (libroEncontrado.getCantidad() - 1 <= 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "¡Préstamo registrado! El libro se ha agotado y ahora figura como 'Prestado'.");
            } else {
                javax.swing.JOptionPane.showMessageDialog(this, "¡Préstamo registrado con éxito! Una unidad fue descontada del inventario.");
            }
            
            listarPrestamos(); 
            restablecerFormulario(); 
            
        } else if (resultado.equals("ERROR_ESTUDIANTE")) {
            javax.swing.JOptionPane.showMessageDialog(this, "El ID del estudiante no existe en los registros.");
        } else if (resultado.equals("ERROR_LIBRO_OCUPADO")) {
            javax.swing.JOptionPane.showMessageDialog(this, "No se puede realizar el préstamo. Este libro no cuenta con unidades disponibles.");
        }

    } catch (java.time.format.DateTimeParseException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Asegurese de ingresar la Fecha Límite completa en formato Día/Mes/Año.");
    }

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained
     if (txtBuscar.getText().equals("(Buscar prestamo por Estado/Titulo)")) {
        txtBuscar.setText("");
        txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
    }

    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
        if (txtBuscar.getText().trim().isEmpty()) {
        txtBuscar.setText("(Buscar prestamo por Estado/Titulo)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }
    }//GEN-LAST:event_txtBuscarFocusLost

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
if (idPrestamoSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, seleccione el préstamo que desea eliminar de la tabla.", 
            "Selección Requerida", 
            javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    int confirmar = javax.swing.JOptionPane.showConfirmDialog(this, 
            "¿Está completamente seguro de eliminar este registro de prestamo?\n" +
            "Esta accion no se puede deshacer y alterara el historial.", 
            "Confirmar Eliminación", 
            javax.swing.JOptionPane.YES_NO_OPTION, 
            javax.swing.JOptionPane.WARNING_MESSAGE);

    if (confirmar == javax.swing.JOptionPane.YES_OPTION) {
        if (controlPrestamo.eliminarPrestamo(idPrestamoSeleccionado)) {
            javax.swing.JOptionPane.showMessageDialog(this, "El registro de préstamo ha sido eliminado correctamente.");
            listarPrestamos(); 
            restablecerFormulario(); 
            txtFechaPrestamo.setText(null);
            txtFechaLimite.setText(null);
            
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "No se pudo eliminar el préstamo de la base de datos.", 
                "Error de Base de Datos", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }       
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtTituloLibroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTituloLibroFocusLost
 actualizarStockInformativo();
    }//GEN-LAST:event_txtTituloLibroFocusLost

    private void buscarestudianteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarestudianteActionPerformed
    RegistrarEstudiante ventanaEstudiante = new RegistrarEstudiante(this);
    ventanaEstudiante.setLocationRelativeTo(null);
    ventanaEstudiante.setVisible(true);
    }//GEN-LAST:event_buscarestudianteActionPerformed

    private void buscarlibroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarlibroActionPerformed
      RegistrarLibro ventanaLibro = new RegistrarLibro(this);
    ventanaLibro.setLocationRelativeTo(null);
    ventanaLibro.setVisible(true);
    }//GEN-LAST:event_buscarlibroActionPerformed

    private void txtTituloLibroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTituloLibroKeyReleased
      actualizarStockInformativo();
    }//GEN-LAST:event_txtTituloLibroKeyReleased

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new RegistrarPrestamo().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnCancelar;
    public javax.swing.JButton btnEliminar;
    public javax.swing.JButton btnGuardar;
    public javax.swing.JButton btnRegistrarDevolucion;
    private javax.swing.JButton buscarestudiante;
    private javax.swing.JButton buscarlibro;
    private javax.swing.JComboBox<String> cbxEstado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblStockInformativo;
    public javax.swing.JTable tablaPrestamos;
    public javax.swing.JTextField txtBuscar;
    private javax.swing.JFormattedTextField txtFechaLimite;
    private javax.swing.JFormattedTextField txtFechaPrestamo;
    public javax.swing.JTextField txtIdEstudiante;
    public javax.swing.JTextField txtIdPrestamo;
    public javax.swing.JTextField txtTituloLibro;
    // End of variables declaration//GEN-END:variables
}
