
package Vista;
import Controlador.RolController;
import Modelo.Rol;
import java.util.List;
import javax.swing.table.DefaultTableModel;
public class GestionRoles extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestionRoles.class.getName());
    public GestionRoles() {
        initComponents();
        listarRoles();
    }
    RolController controlRol = new RolController();
public void listarRoles() {
    List<Rol> lista = controlRol.obtenerTodos();
    DefaultTableModel modelo = (DefaultTableModel) tablaRoles.getModel();
    modelo.setRowCount(0);
    
    Object[] fila = new Object[4];
    for (Rol r : lista) {
        fila[0] = r.getId();
        fila[1] = r.getNombreRol();
        fila[2] = r.getDescripcion();
        fila[3] = r.getEstado();
        modelo.addRow(fila);
    }
}
private void limpiarCampos() {
    txtId.setText("");
    txtDescripcion.setText("");
    if (cbRol.getItemCount() > 0) {
        cbRol.setSelectedIndex(0);
    }
    if (cbEstado.getItemCount() > 0) {
        cbEstado.setSelectedIndex(0);
    }
    tablaRoles.clearSelection();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaRoles = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cbEstado = new javax.swing.JComboBox<>();
        cbRol = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        btnLimpiarRol = new javax.swing.JButton();
        btnGuardarRol = new javax.swing.JButton();

        jLabel7.setText("jLabel7");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Gestion de roles y permisos");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, -1, -1));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, -1, -1));

        tablaRoles.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Roles", "Descripcion", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaRoles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaRolesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaRoles);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 620, 320));

        jLabel3.setText("ID:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        txtId.setEditable(false);
        txtId.setEnabled(false);
        getContentPane().add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 110, -1));

        jLabel4.setText("Rol:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 90, 30, -1));

        jLabel5.setText("Descripcion:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, -1, -1));

        txtDescripcion.setEditable(false);
        getContentPane().add(txtDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 90, 110, -1));

        jLabel6.setText("Estado:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, -1, -1));

        cbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));
        getContentPane().add(cbEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 90, -1, -1));

        cbRol.setEditable(true);
        cbRol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "Administrador", "Bibliotecario", "Estudiante" }));
        cbRol.setEnabled(false);
        getContentPane().add(cbRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 110, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\Alexi\\OneDrive\\Pictures\\Desktop\\imagenes netbeans biblioteac\\Gestion de roles\\Sin título.png")); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, -1, -1));

        btnLimpiarRol.setBackground(new java.awt.Color(204, 204, 204));
        btnLimpiarRol.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLimpiarRol.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiarRol.setText("Limpiar");
        btnLimpiarRol.addActionListener(this::btnLimpiarRolActionPerformed);
        getContentPane().add(btnLimpiarRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 460, 90, 40));

        btnGuardarRol.setBackground(new java.awt.Color(117, 189, 107));
        btnGuardarRol.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGuardarRol.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardarRol.setText("Guardar");
        btnGuardarRol.addActionListener(this::btnGuardarRolActionPerformed);
        getContentPane().add(btnGuardarRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 460, 110, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarRolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarRolActionPerformed
    int id = txtId.getText().isEmpty() ? 0 : Integer.parseInt(txtId.getText());
    String rol = cbRol.getSelectedItem().toString();
    String desc = txtDescripcion.getText().trim();
    String estado = cbEstado.getSelectedItem().toString();

    if (rol.equalsIgnoreCase("Administrador") && estado.equalsIgnoreCase("Inactivo")) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por motivos de seguridad, el rol 'Administrador' no puede ser configurado como Inactivo.", 
            "Acceso Denegado", 
            javax.swing.JOptionPane.ERROR_MESSAGE);
        cbEstado.setSelectedItem("Activo");
        return;
    }

    if (controlRol.registrarOEditar(id, rol, desc, estado)) {
        javax.swing.JOptionPane.showMessageDialog(this, "¡Rol procesado correctamente!");
        limpiarCampos();
        listarRoles();
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: Verifique los campos obligatorios.");
    }

    }//GEN-LAST:event_btnGuardarRolActionPerformed

    private void btnLimpiarRolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarRolActionPerformed
      limpiarCampos();
    }//GEN-LAST:event_btnLimpiarRolActionPerformed

    private void tablaRolesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaRolesMouseClicked
     int filaSeleccionada = tablaRoles.getSelectedRow();
    if (filaSeleccionada >= 0) {
        txtId.setText(tablaRoles.getValueAt(filaSeleccionada, 0).toString());
        cbRol.setSelectedItem(tablaRoles.getValueAt(filaSeleccionada, 1).toString());
        txtDescripcion.setText(tablaRoles.getValueAt(filaSeleccionada, 2).toString());
        cbEstado.setSelectedItem(tablaRoles.getValueAt(filaSeleccionada, 3).toString());
    }

    }//GEN-LAST:event_tablaRolesMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GestionRoles().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnGuardarRol;
    public javax.swing.JButton btnLimpiarRol;
    public javax.swing.JComboBox<String> cbEstado;
    public javax.swing.JComboBox<String> cbRol;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable tablaRoles;
    public javax.swing.JTextField txtDescripcion;
    public javax.swing.JTextField txtId;
    // End of variables declaration//GEN-END:variables
}
