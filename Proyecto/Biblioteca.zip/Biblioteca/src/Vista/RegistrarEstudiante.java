package Vista;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class RegistrarEstudiante extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(RegistrarEstudiante.class.getName());
   private RegistrarPrestamo ventanaPrestamo = null;
    private Controlador.EstudianteController controlEstudiante = new Controlador.EstudianteController();
    private int idEstudianteSeleccionado = -1;
    
  public RegistrarEstudiante() {
    initComponents();
    listarEstudiantes();
    txtBuscar.setText("(Buscar Estudiante)");
    txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
}

public RegistrarEstudiante(RegistrarPrestamo ventanaPrestamo) {
    this();
    this.ventanaPrestamo = ventanaPrestamo;
}
    public void limpiarCampos() {
    txtNombres.setText("");
    txtApellidos.setText("");
    txtTelefono.setText("");
    cbGrado.setSelectedIndex(0);
    txtSeccion.setText("");
    txtBuscar.setText("");
     txtBuscar.setText("(Buscar Estudiante)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
}
  
 public void listarEstudiantes() {
    java.util.List<Modelo.Estudiante> lista = controlEstudiante.obtenerTodos();
    DefaultTableModel modelo = (DefaultTableModel) tablaEstudiantes.getModel();
    modelo.setRowCount(0);
    
    Object[] fila = new Object[6];
    for (Modelo.Estudiante e : lista) {
        fila[0] = e.getId();
        fila[1] = e.getNombre();
        fila[2] = e.getApellido();
        fila[3] = e.getTelefono();
        fila[4] = e.getGrado();
        fila[5] = e.getSeccion();
        
        modelo.addRow(fila);
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtNombres = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        cbGrado = new javax.swing.JComboBox<>();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaEstudiantes = new javax.swing.JTable();
        btnLimpiar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        txtSeccion = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Registrar Estudiantes");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, -1, 20));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Seccion:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Nombre:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Apellido:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Telefono:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 90, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Grado:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 120, -1, -1));
        getContentPane().add(txtNombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 170, -1));
        getContentPane().add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 170, -1));

        cbGrado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Seleccionar grado--", "7mo", "8vo", "9no", "10mo", "11mo" }));
        cbGrado.addActionListener(this::cbGradoActionPerformed);
        getContentPane().add(cbGrado, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 120, 150, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addActionListener(this::txtBuscarActionPerformed);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 310, -1));

        tablaEstudiantes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Apellido", "Telefono", "Grado", "Seccion"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaEstudiantes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaEstudiantesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaEstudiantes);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 756, 288));

        btnLimpiar.setBackground(new java.awt.Color(153, 153, 153));
        btnLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(this::btnLimpiarActionPerformed);
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 80, 30));

        btnGuardar.setBackground(new java.awt.Color(117, 189, 107));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, 80, 30));

        btnEliminar.setBackground(new java.awt.Color(244, 67, 54));
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 240, 80, 30));

        btnActualizar.setBackground(new java.awt.Color(73, 144, 180));
        btnActualizar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(this::btnActualizarActionPerformed);
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 240, 90, 30));
        getContentPane().add(txtSeccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 160, 150, -1));
        getContentPane().add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 90, 150, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void cbGradoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbGradoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbGradoActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
if (idEstudianteSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione un estudiante de la tabla para eliminar.");
        return;
    }

    String nombreCompleto = txtNombres.getText().trim() + " " + txtApellidos.getText().trim();

    int respuesta = javax.swing.JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de eliminar de forma permanente al estudiante: " + nombreCompleto + "?", 
            "Confirmar Eliminación", 
            javax.swing.JOptionPane.YES_NO_OPTION, 
            javax.swing.JOptionPane.WARNING_MESSAGE);

    if (respuesta == javax.swing.JOptionPane.YES_OPTION) {
        controlEstudiante.eliminarEstudiante(idEstudianteSeleccionado);
        
        listarEstudiantes();
        limpiarCampos();
        
        idEstudianteSeleccionado = -1;
        btnGuardar.setEnabled(true);
        tablaEstudiantes.clearSelection();
        
        javax.swing.JOptionPane.showMessageDialog(this, "Estudiante eliminado del sistema.");
    }

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
String nombre = txtNombres.getText().trim();
    String apellido = txtApellidos.getText().trim();
    String telefono = txtTelefono.getText().trim();
    String grado = cbGrado.getSelectedItem().toString(); 
    String seccion = txtSeccion.getText().trim();

    if (nombre.isEmpty() || apellido.isEmpty() || seccion.isEmpty() || telefono.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.", "Campos Vacíos", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    if (cbGrado.getSelectedIndex() == 0 || grado.equals("--Seleccionar grado--")) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione un grado válido para el estudiante.", "Grado requerido", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    if (!telefono.matches("\\d{8}")) {
        javax.swing.JOptionPane.showMessageDialog(this, "El número de teléfono debe contener exactamente 8 dígitos numéricos (sin guiones ni espacios).", "Teléfono Inválido", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtTelefono.requestFocus();
        return;
    }
   if (controlEstudiante.existeEstudiante(nombre, apellido, -1)) {
    javax.swing.JOptionPane.showMessageDialog(this, 
            "Ya existe un estudiante registrado con el nombre '" + nombre + " " + apellido + "'.", 
            "Estudiante Duplicado", 
            javax.swing.JOptionPane.WARNING_MESSAGE);
    txtNombres.requestFocus();
    return;
}

    boolean exito = controlEstudiante.registrar(nombre, apellido, telefono, grado, seccion);
    
    if (exito) {
        listarEstudiantes();
        limpiarCampos();
        javax.swing.JOptionPane.showMessageDialog(this, "Estudiante registrado con éxito.");
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar el estudiante en la base de datos.", "Error BD", javax.swing.JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
limpiarCampos();
btnGuardar.setEnabled(true);
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void tablaEstudiantesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaEstudiantesMouseClicked
 int fila = tablaEstudiantes.getSelectedRow();
    
    if (fila == -1) {
        return;
    }
    if (evt.getClickCount() == 2) {
        String nombre = tablaEstudiantes.getValueAt(fila, 1).toString();
        String apellido = tablaEstudiantes.getValueAt(fila, 2).toString();
        String nombreCompleto = nombre + " " + apellido;
        
        if (ventanaPrestamo != null) {
            ventanaPrestamo.txtIdEstudiante.setText(nombreCompleto);
            this.dispose();
        }
    } 
    else if (evt.getClickCount() == 1) {
        idEstudianteSeleccionado = Integer.parseInt(tablaEstudiantes.getValueAt(fila, 0).toString());
        txtNombres.setText(tablaEstudiantes.getValueAt(fila, 1).toString());
        txtApellidos.setText(tablaEstudiantes.getValueAt(fila, 2).toString());
        txtTelefono.setText(tablaEstudiantes.getValueAt(fila, 3).toString());
        cbGrado.setSelectedItem(tablaEstudiantes.getValueAt(fila, 4).toString());
        txtSeccion.setText(tablaEstudiantes.getValueAt(fila, 5).toString());
        
        btnGuardar.setEnabled(false);
    }
    }//GEN-LAST:event_tablaEstudiantesMouseClicked

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
if (idEstudianteSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione un estudiante de la tabla para actualizar.");
        return;
    }
    
    String nombre = txtNombres.getText().trim();
    String apellido = txtApellidos.getText().trim();
    String telefono = txtTelefono.getText().trim();
    String grado = cbGrado.getSelectedItem().toString();
    String seccion = txtSeccion.getText().trim();

    if (nombre.isEmpty() || apellido.isEmpty() || seccion.isEmpty() || telefono.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.", "Campos Vacíos", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    if (cbGrado.getSelectedIndex() == 0 || grado.equals("--Seleccionar grado--")) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione un grado válido para el estudiante.", "Grado requerido", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    if (!telefono.matches("\\d{8}")) {
        javax.swing.JOptionPane.showMessageDialog(this, "El número de teléfono debe contener exactamente 8 dígitos numéricos (sin guiones ni espacios).", "Teléfono Inválido", javax.swing.JOptionPane.WARNING_MESSAGE);
        txtTelefono.requestFocus();
        return;
    }

   if (controlEstudiante.existeEstudiante(nombre, apellido, idEstudianteSeleccionado)) {
    javax.swing.JOptionPane.showMessageDialog(this, 
            "Ya existe otro estudiante registrado con el nombre '" + nombre + " " + apellido + "'.", 
            "Estudiante Duplicado", 
            javax.swing.JOptionPane.WARNING_MESSAGE);
    txtNombres.requestFocus();
    return;
}

    controlEstudiante.actualizarEstudiante(idEstudianteSeleccionado, nombre, apellido, telefono, grado, seccion);

    listarEstudiantes();
    limpiarCampos();
    idEstudianteSeleccionado = -1;
    btnGuardar.setEnabled(true);
    tablaEstudiantes.clearSelection();

    javax.swing.JOptionPane.showMessageDialog(this, "Datos del estudiante actualizados correctamente.");

    }//GEN-LAST:event_btnActualizarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
String texto = txtBuscar.getText().trim();
    java.util.List<Modelo.Estudiante> filtrada = controlEstudiante.buscarEstudiante(texto);
    
    DefaultTableModel modelo = (DefaultTableModel) tablaEstudiantes.getModel();
    modelo.setRowCount(0);
    
    Object[] fila = new Object[6];
    for (Modelo.Estudiante e : filtrada) {
        fila[0] = e.getId();
        fila[1] = e.getNombre();
        fila[2] = e.getApellido();
        fila[3] = e.getTelefono();
        fila[4] = e.getGrado();
        fila[5] = e.getSeccion();
        modelo.addRow(fila);
    }
   
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained
       if (txtBuscar.getText().equals("(Buscar Estudiante)")) {
        txtBuscar.setText("");
        txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
    }
    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
     if (txtBuscar.getText().trim().isEmpty()) {
        txtBuscar.setText("(Buscar Estudiante)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
    }
    }//GEN-LAST:event_txtBuscarFocusLost

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new RegistrarEstudiante().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnActualizar;
    public javax.swing.JButton btnEliminar;
    public javax.swing.JButton btnGuardar;
    public javax.swing.JButton btnLimpiar;
    public javax.swing.JComboBox<String> cbGrado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable tablaEstudiantes;
    public javax.swing.JTextField txtApellidos;
    public javax.swing.JTextField txtBuscar;
    public javax.swing.JTextField txtNombres;
    private javax.swing.JTextField txtSeccion;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
