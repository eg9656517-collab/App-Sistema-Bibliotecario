
package Vista;

public class RegistrarEditorial extends javax.swing.JDialog {
    private RegistrarLibro ventanaLibro;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(RegistrarEditorial.class.getName());
private int idSeleccionado = -1;

    public RegistrarEditorial(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        if (parent instanceof RegistrarLibro) {this.ventanaLibro = (RegistrarLibro) parent;}
       llenarTabla(""); 
       txtBuscar.setText("(Buscar Editorial)");
        txtBuscar.setForeground(new java.awt.Color(153, 153, 153));

    }
public void llenarTabla(String texto) {
    javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) tablaEditorial.getModel();
    modelo.setRowCount(0);
    
    Controlador.EditorialController controlEd = new Controlador.EditorialController();
    
    for (Modelo.Editorial ed : controlEd.obtenerEditoriales()) {
        if (ed.getNombre().toLowerCase().contains(texto.toLowerCase()) || 
            ed.getPais().toLowerCase().contains(texto.toLowerCase())) {
            
            modelo.addRow(new Object[]{
                ed.getId_editorial(), 
                ed.getNombre(), 
                ed.getPais()
            });
        }
    }
}
private void limpiarFormulario() {
    txtNombreEditorial.setText("");
    txtPais.setText("");
    if(txtBuscar != null) txtBuscar.setText("");
    idSeleccionado = -1;
    btnGuardar.setEnabled(true);
    llenarTabla("");
     txtBuscar.setText("(Buscar Editorial)");
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaEditorial = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        txtNombreEditorial = new javax.swing.JTextField();
        txtPais = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Registrar Editorial");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 320, -1));

        tablaEditorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID_Editorial", "Nombre", "Pais"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaEditorial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaEditorialMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaEditorial);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 450, 250));

        jLabel2.setText("Nombre:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        jLabel3.setText("Pais:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, -1, -1));

        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBuscarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBuscarFocusLost(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        getContentPane().add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 300, -1));
        getContentPane().add(txtNombreEditorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 160, -1));
        getContentPane().add(txtPais, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 160, -1));

        btnGuardar.setBackground(new java.awt.Color(117, 189, 107));
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, -1, -1));

        btnActualizar.setBackground(new java.awt.Color(73, 144, 180));
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(this::btnActualizarActionPerformed);
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 460, -1, -1));

        btnEliminar.setBackground(new java.awt.Color(244, 87, 54));
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, -1, -1));

        btnLimpiar.setBackground(new java.awt.Color(153, 153, 153));
        btnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(this::btnLimpiarActionPerformed);
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 460, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tablaEditorialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaEditorialMouseClicked
int filaSeleccionada = tablaEditorial.getSelectedRow();
    if (filaSeleccionada != -1) {
        if (evt.getClickCount() == 2) {
            String nombreEditorial = tablaEditorial.getValueAt(filaSeleccionada, 1).toString();
            
            if (ventanaLibro != null) {
                ventanaLibro.txtEditorial.setText(nombreEditorial);
                this.dispose(); 
            }
        } 
        else if (evt.getClickCount() == 1) {
            txtNombreEditorial.setText(tablaEditorial.getValueAt(filaSeleccionada, 1).toString());
            txtPais.setText(tablaEditorial.getValueAt(filaSeleccionada, 2).toString());
        }
        btnGuardar.setEnabled(false);
    }
      
    }//GEN-LAST:event_tablaEditorialMouseClicked

    private void txtBuscarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusGained
        if (txtBuscar.getText().equals("(Buscar Editorial)")) {
            txtBuscar.setText("");
            txtBuscar.setForeground(new java.awt.Color(0, 0, 0));
        }
    }//GEN-LAST:event_txtBuscarFocusGained

    private void txtBuscarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBuscarFocusLost
        if (txtBuscar.getText().trim().isEmpty()) {
            txtBuscar.setText("(Buscar Editorial)");
            txtBuscar.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_txtBuscarFocusLost

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
 llenarTabla(txtBuscar.getText().trim());
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
 String nombre = txtNombreEditorial.getText().trim();
    String pais = txtPais.getText().trim();

    if (nombre.isEmpty() || pais.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Complete todos los campos.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    Controlador.EditorialController controlEd = new Controlador.EditorialController();
    if (controlEd.existeNombreEditorial(nombre, -1)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Ya existe una editorial registrada con el nombre: " + nombre, 
                "Editorial Duplicada", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
        txtNombreEditorial.requestFocus();
        return;
    }

    if (controlEd.registrarEditorial(nombre, pais)) {
        javax.swing.JOptionPane.showMessageDialog(this, "Editorial guardada correctamente.");
        txtNombreEditorial.setText("");
        txtPais.setText("");
        llenarTabla("");
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }     

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
    int filaSeleccionada = tablaEditorial.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione un registro de la tabla.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    String nombre = txtNombreEditorial.getText().trim();
    String pais = txtPais.getText().trim();
    int idEditorial = Integer.parseInt(tablaEditorial.getValueAt(filaSeleccionada, 0).toString());

    if (nombre.isEmpty() || pais.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Los campos no pueden quedar vacíos.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    Controlador.EditorialController controlEd = new Controlador.EditorialController();

    if (controlEd.existeNombreEditorial(nombre, idEditorial)) {
        javax.swing.JOptionPane.showMessageDialog(this, 
                "Ya existe otra editorial registrada con el nombre: " + nombre, 
                "Editorial Duplicada", 
                javax.swing.JOptionPane.WARNING_MESSAGE);
        txtNombreEditorial.requestFocus();
        return;
    }

    if (controlEd.modificarEditorial(idEditorial, nombre, pais)) {
        javax.swing.JOptionPane.showMessageDialog(this, "Editorial actualizada correctamente.");
        txtNombreEditorial.setText("");
        txtPais.setText("");
        llenarTabla("");
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al actualizar la editorial.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
int filaSeleccionada = tablaEditorial.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione un registro de la tabla.");
        return;
    }
    
    int idEditorial = Integer.parseInt(tablaEditorial.getValueAt(filaSeleccionada, 0).toString());
    String nombre = tablaEditorial.getValueAt(filaSeleccionada, 1).toString();
    
    int confirmar = javax.swing.JOptionPane.showConfirmDialog(this, "¿Eliminar la editorial " + nombre + "?", "Confirmar", javax.swing.JOptionPane.YES_NO_OPTION);
    if (confirmar == javax.swing.JOptionPane.YES_OPTION) {
        Controlador.EditorialController controlEd = new Controlador.EditorialController();
        if (controlEd.eliminarEditorial(idEditorial)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Editorial eliminada.");
            txtNombreEditorial.setText("");
            txtPais.setText("");
            llenarTabla("");
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Error al eliminar. Verifique dependencias.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
     
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
     limpiarFormulario();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                RegistrarEditorial dialog = new RegistrarEditorial(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaEditorial;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtNombreEditorial;
    private javax.swing.JTextField txtPais;
    // End of variables declaration//GEN-END:variables
}
