package Vista;
import javax.swing.JOptionPane;
import Controlador.UsuarioLoginController;

public class Login extends javax.swing.JFrame {
    UsuarioLoginController control = new UsuarioLoginController();
    private Controlador.UsuarioController controlUsuario = new Controlador.UsuarioController();
    public Login() {
        initComponents();
        this.setLocationRelativeTo(null); 
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnIniciar = new javax.swing.JButton();
        txtContrasena = new javax.swing.JPasswordField();
        jLabel7 = new javax.swing.JLabel();
        txtNombreUsuario = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(1440, 1024, 0, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));

        jPanel2.setBackground(new java.awt.Color(213, 223, 229));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnIniciar.setBackground(new java.awt.Color(89, 101, 242));
        btnIniciar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnIniciar.setForeground(new java.awt.Color(255, 255, 255));
        btnIniciar.setText("Iniciar Seccion");
        btnIniciar.setBorder(null);
        btnIniciar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnIniciar.addActionListener(this::btnIniciarActionPerformed);
        jPanel2.add(btnIniciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 280, 200, 40));
        jPanel2.add(txtContrasena, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 170, 220, -1));

        jLabel7.setText("Contraseña");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 140, -1, -1));
        jPanel2.add(txtNombreUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, 220, -1));

        jLabel6.setText("Nombre de usuario");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Iniciar Seccion ");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, 130, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("\"San Juan Bautista\" Cuapa");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Biblioteca");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Bienvenido");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, -1, -1));

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\Alexi\\OneDrive\\Pictures\\Desktop\\Netbeans Login.png")); // NOI18N
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 190, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 480, 350));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed
String usuarioInput = txtNombreUsuario.getText().trim();
    String contrasenaInput = new String(txtContrasena.getPassword()); 
    
    if (usuarioInput.isEmpty() || contrasenaInput.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, introduzca su usuario y contraseña.", 
            "Campos Vacíos", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    Controlador.UsuarioLoginController controlUsuarioLogin = new Controlador.UsuarioLoginController();
    
    if (controlUsuarioLogin.validarIngreso(usuarioInput, contrasenaInput)) {
        String rolDesdeBD = controlUsuarioLogin.obtenerRolUsuario(usuarioInput).trim();
        Controlador.RolController controlRol = new Controlador.RolController();
        Modelo.Rol rolEncontrado = null;
        
        for (Modelo.Rol r : controlRol.obtenerTodos()) {
            if (r.getNombreRol().trim().equalsIgnoreCase(rolDesdeBD)) {
                rolEncontrado = r;
                break;
            }
        }
        
        if (rolEncontrado != null && rolEncontrado.getEstado().trim().equalsIgnoreCase("Inactivo")) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "El acceso para el rol '" + rolDesdeBD + "' está temporalmente deshabilitado por el administrador.", 
                "Acceso Denegado", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

  String rolUpper = rolDesdeBD.toUpperCase();
if (rolUpper.contains("ADMIN")) {
    Modelo.UsuarioLogin.setCredenciales("admin_db", "Admin#2026_MYSQL");
} else {
    Modelo.UsuarioLogin.setCredenciales("biblio_db", "Biblio#2026_MYSQL");
}
        
        Controlador.RolController.setRolActivo(rolEncontrado);
        MenuPrincipal menu = new MenuPrincipal(rolDesdeBD); 
        menu.setVisible(true);
        this.dispose();
        
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Usuario o contraseña incorrectos.", 
            "Error de Acceso", javax.swing.JOptionPane.ERROR_MESSAGE);
        txtNombreUsuario.setText("");
        txtContrasena.setText("");
        txtNombreUsuario.requestFocus();
    }

    }//GEN-LAST:event_btnIniciarActionPerformed

    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
    java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
}java.awt.EventQueue.invokeLater(() -> new Login().setVisible(true));
        }
 
        
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnIniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    public javax.swing.JPasswordField txtContrasena;
    public javax.swing.JTextField txtNombreUsuario;
    // End of variables declaration//GEN-END:variables
}
