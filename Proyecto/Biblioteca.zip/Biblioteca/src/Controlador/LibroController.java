package Controlador;
import Modelo.DAOLibro;
import Modelo.Libro;
import java.util.ArrayList;
import java.util.List;

public class LibroController {
    private DAOLibro dao = new DAOLibro();

    public LibroController() {
    }
    public boolean registrar(String titulo, String autor, String categoria, String editorial, String anoPublicacion, String disponibilidad, String ubicacion, int cantidad) {
        Libro l = new Libro(0, cantidad, titulo, autor, categoria, editorial, anoPublicacion, disponibilidad, ubicacion);
        return dao.insertar(l); 
    }
 public boolean existeLibroPorTitulo(String titulo, int idExcluir) {
    return dao.existeLibroPorTitulo(titulo, idExcluir);
}

    public List<Libro> obtenerTodos() {
        return dao.listar();
    } 
    public boolean actualizarLibro(int codigo, String titulo, String autor, String categoria, String editorial, String anoPublicacion, String disponibilidad, String ubicacion, int cantidad) {
        Libro l = new Libro(codigo, cantidad, titulo, autor, categoria, editorial, anoPublicacion, disponibilidad, ubicacion);
        return dao.actualizar(l); 
    }


    public boolean eliminarLibro(int codigo) {
        return dao.eliminar(codigo);
    }
    public List<Libro> buscarLibro(String texto) {
        List<Libro> filtrada = new ArrayList<>();
        for (Libro l : dao.listar()) {
            if (l.getTitulo().toLowerCase().contains(texto.toLowerCase()) ||
                l.getAutor().toLowerCase().contains(texto.toLowerCase()) ||
                l.getCategoria().toLowerCase().contains(texto.toLowerCase())) {
                filtrada.add(l);
            }
        }
        return filtrada;
    }

public String obtenerTituloPorCodigo(int codigo) {
    for (Libro l : dao.listar()) { 
        if (l.getCodigo() == codigo) {
            return l.getTitulo();
        }
    }
    return "Libro no encontrado";
}
public int obtenerStockPorTitulo(String titulo) {
    for (Libro l : dao.listar()) { 
        if (l.getTitulo().equalsIgnoreCase(titulo.trim())) {
            return l.getCantidad();
        }
    }
    return -1;
}
}

