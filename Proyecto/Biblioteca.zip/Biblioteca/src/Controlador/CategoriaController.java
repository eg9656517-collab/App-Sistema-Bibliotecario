package Controlador;
import Modelo.DAOCategoria;
import Modelo.Categoria;
import java.util.List;

public class CategoriaController {
    private DAOCategoria dao = new DAOCategoria();
    public boolean registrarCategoria(String nombre, String descripcion) {
        Categoria nuevaCategoria = new Categoria();
        nuevaCategoria.setNombre(nombre);
        nuevaCategoria.setDescripcion(descripcion);
        return dao.insertar(nuevaCategoria);
    }

    public List<Categoria> obtenerCategorias() {
        return dao.listarCategorias();
    }
    public boolean modificarCategoria(int id, String nombre, String descripcion) {
    Modelo.Categoria cat = new Modelo.Categoria(id, nombre, descripcion);
    return dao.modificar(cat);
}

public boolean eliminarCategoria(int id) {
    return dao.eliminar(id);
}
public boolean existeNombreCategoria(String nombre, int idExcluir) {
    return dao.existeNombreCategoria(nombre, idExcluir);
}
}