package Controlador;
import Modelo.DAOUsuario;
import Modelo.Usuario;
import java.util.ArrayList;
import java.util.List;

public class UsuarioController {
    private DAOUsuario dao = new DAOUsuario();
    public boolean registrar(String nc, String nu, String c, String cor, String tel, String r) {
        if (dao.existeUsuario(nu)) return false; 
        Usuario nuevo = new Usuario(0, nc, nu, c, cor, tel, r); 
        dao.guardar(nuevo);
        return true;
    }

    public List<Usuario> obtenerTodos() {
        return dao.listar();
    }
    
    public void actualizar(int id, String nc, String nu, String c, String cor, String tel, String r) {
        Usuario editado = new Usuario(id, nc, nu, c, cor, tel, r);
        dao.actualizar(editado);
    }
    public void eliminarUsuario(int id) {
        dao.eliminar(id);
    }
    public List<Usuario> buscarPorNombreUsuario(String texto) {
        List<Usuario> filtrada = new ArrayList<>();
        for (Usuario u : dao.listar()) {
            if (u.getNombreUsuario().toLowerCase().contains(texto.toLowerCase())) {
                filtrada.add(u);
            }
        }
        return filtrada;
    }
    public java.util.List<Usuario> buscarUsuario(String texto) {
    java.util.List<Usuario> filtrada = new java.util.ArrayList<>();
    for (Usuario u : dao.listar()) {
        if (u.getNombreCompleto().toLowerCase().contains(texto.toLowerCase()) ||
            u.getNombreUsuario().toLowerCase().contains(texto.toLowerCase())) {
            filtrada.add(u);
        }
    }
    return filtrada;
}
    public boolean existeIdUsuario(int id) {
    for (Usuario u : dao.listar()) {
        if (u.getId() == id) {
            return true; 
        }
    }
    return false; 
}
    public boolean login(String username, String password) {
    for (Modelo.Usuario u : obtenerTodos()) {
        if (u.getNombreUsuario().equals(username) && u.getContrasena().equals(password)) {
            return true;
        }
    }
    return false;
}
}