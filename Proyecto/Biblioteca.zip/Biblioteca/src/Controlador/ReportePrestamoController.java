package Controlador;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import Modelo.DAOReportes;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class ReportePrestamoController {
    
    private final DAOReportes daoReportes = new DAOReportes();

    public void cargarTablaReportes(JTable tabla, String tipoFiltro, String categoria, String seccion, java.util.Date fechaDesde, java.util.Date fechaHasta) {
        DefaultTableModel modelo;
        String filtro = tipoFiltro != null ? tipoFiltro.trim() : "";
        
        switch (filtro) {
            case "Prestamos Activos":
                modelo = new DefaultTableModel(
                    new Object[]{"ID", "Libro", "Estudiante", "Sección", "F. Límite", "Días Restantes"}, 0
                ) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                };

                try {
                    List<Modelo.ReportePrestamo> lista = daoReportes.listarReporteAvanzado("Activo", categoria, seccion, fechaDesde, fechaHasta);
                    LocalDate hoy = LocalDate.now();
                    
                    for (Modelo.ReportePrestamo r : lista) {
                        long diasRestantes = ChronoUnit.DAYS.between(hoy, r.getFechaLimite());
                        modelo.addRow(new Object[]{
                            r.getIdPrestamo(),
                            r.getLibro(),
                            r.getEstudiante(),
                            r.getSeccion(),
                            r.getFechaLimite(),
                            diasRestantes >= 0 ? diasRestantes + " días" : "¡Vence hoy!"
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                tabla.setModel(modelo);
                break;

            case "Prestamos Vencidos":
                modelo = new DefaultTableModel(
                    new Object[]{"ID", "Libro", "Estudiante", "Sección", "F. Límite", "Días de Retraso", "Estado"}, 0
                ) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                };

                try {
                    List<Modelo.ReportePrestamo> lista = daoReportes.listarReporteAvanzado("Vencido", categoria, seccion, fechaDesde, fechaHasta);
                    LocalDate hoy = LocalDate.now();
                    
                    for (Modelo.ReportePrestamo r : lista) {
                        long diasRetraso = ChronoUnit.DAYS.between(r.getFechaLimite(), hoy);
                        modelo.addRow(new Object[]{
                            r.getIdPrestamo(),
                            r.getLibro(),
                            r.getEstudiante(),
                            r.getSeccion(),
                            r.getFechaLimite(),
                            diasRetraso + " días tarde",
                            r.getEstado()
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                tabla.setModel(modelo);
                aplicarFormatoRojo(tabla, 5); 
                break;

            case "Inventario de libros":
                modelo = new DefaultTableModel(
                    new Object[]{"ID", "Título", "Autor", "Categoría", "Disponibilidad", "Cantidad"}, 0
                ) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                };

                try {
                    List<Modelo.Libro> lista = daoReportes.listarInventarioLibros(categoria);
                    for (Modelo.Libro l : lista) {
                        modelo.addRow(new Object[]{
                            l.getCodigo(),
                            l.getTitulo(),
                            l.getAutor(),
                            l.getCategoria(),
                            l.getDisponibilidad(),
                            l.getCantidad() + " unidades"
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                tabla.setModel(modelo);
                break;

            case "Libros mas Prestados":
                modelo = new DefaultTableModel(
                    new Object[]{"Título del Libro", "Autor", "Categoría", "Total de Préstamos"}, 0
                ) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                };

                try {
                    List<Modelo.ReporteLibroPopular> lista = daoReportes.listarLibrosMasPrestadosFiltrados(categoria, fechaDesde, fechaHasta);
                    for (Modelo.ReporteLibroPopular r : lista) {
                        modelo.addRow(new Object[]{
                            r.getTitulo(),
                            r.getAutor(),
                            r.getCategoria(),
                            r.getTotalPrestamos() + " veces"
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                tabla.setModel(modelo);
                break;

            case "Secciones con mas prestamos":
                modelo = new DefaultTableModel(
                    new Object[]{"Sección del Estudiante", "Total de Préstamos"}, 0
                ) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                };

                try {
                    List<Modelo.ReporteSeccionPopular> lista = daoReportes.listarSeccionesMasPrestamos(fechaDesde, fechaHasta);
                    for (Modelo.ReporteSeccionPopular r : lista) {
                        modelo.addRow(new Object[]{
                            r.getSeccion() != null && !r.getSeccion().isEmpty() ? "Sección " + r.getSeccion() : "Sin Sección",
                            r.getTotalPrestamos() + " préstamos"
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                tabla.setModel(modelo);
                break;

            default: // "Todos los prestamos" 
                modelo = new DefaultTableModel(
                    new Object[]{"ID", "Libro", "Estudiante", "Sección", "F. Préstamo", "F. Límite", "Estado"}, 0
                ) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                };

                try {
                    String estadoFiltro = (filtro.equals("Todos los prestamos") || filtro.equals("Todos")) ? null : filtro;
                    List<Modelo.ReportePrestamo> lista = daoReportes.listarReporteAvanzado(estadoFiltro, categoria, seccion, fechaDesde, fechaHasta);
                    
                    for (Modelo.ReportePrestamo r : lista) {
                        modelo.addRow(new Object[]{
                            r.getIdPrestamo(),
                            r.getLibro(),
                            r.getEstudiante(),
                            r.getSeccion(),
                            r.getFechaPrestamo(),
                            r.getFechaLimite(),
                            r.getEstado()
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                tabla.setModel(modelo);
                break;
        }
    }

    public void cargarTablaReportes(JTable tabla, String tipoFiltro) {
        cargarTablaReportes(tabla, tipoFiltro, "Todas las categorías", "", null, null);
    }

    private void aplicarFormatoRojo(JTable tabla, int columnaIndex) {
        tabla.getColumnModel().getColumn(columnaIndex).setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                java.awt.Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (value != null && value.toString().contains("tarde")) {
                    c.setForeground(new java.awt.Color(200, 0, 0)); 
                    setFont(getFont().deriveFont(java.awt.Font.BOLD));
                } else {
                    c.setForeground(java.awt.Color.BLACK);
                    setFont(getFont().deriveFont(java.awt.Font.PLAIN));
                }
                return c;
            }
        });
    }
    
    // GENERADOR DE GRAFICOS
  public void cargarGraficoReportes(javax.swing.JPanel panelContenedor, String tipoFiltro, String categoria, String seccion, java.util.Date fechaDesde, java.util.Date fechaHasta) {
    try {
        org.jfree.chart.JFreeChart chart = null;
        String filtro = tipoFiltro != null ? tipoFiltro.trim() : "";
        
        switch (filtro) {
            case "Libros mas Prestados":
            case "Libros más Prestados": {
                List<Modelo.ReporteLibroPopular> lista = daoReportes.listarLibrosMasPrestadosFiltrados(categoria, fechaDesde, fechaHasta);
                org.jfree.data.category.DefaultCategoryDataset dataset = new org.jfree.data.category.DefaultCategoryDataset();
                
                int contador = 0;
                for (Modelo.ReporteLibroPopular r : lista) {
                    if (contador >= 5) break; // Limitamos el gráfico estrictamente al Top 5
                    dataset.addValue(r.getTotalPrestamos(), "Préstamos", r.getTitulo());
                    contador++;
                }
                
                chart = org.jfree.chart.ChartFactory.createBarChart(
                    "Top 5: Libros Más Prestados", "Libros", "Total", dataset,
                    org.jfree.chart.plot.PlotOrientation.VERTICAL, false, true, false
                );
                break;
            } 
            case "Secciones con mas prestamos":
            case "Secciones con más préstamos": {
                List<Modelo.ReporteSeccionPopular> lista = daoReportes.listarSeccionesMasPrestamos(fechaDesde, fechaHasta);
                org.jfree.data.category.DefaultCategoryDataset dataset = new org.jfree.data.category.DefaultCategoryDataset();
                
                int contador = 0;
                for (Modelo.ReporteSeccionPopular r : lista) {
                    if (contador >= 5) break;
                    dataset.addValue(r.getTotalPrestamos(), "Préstamos", "Sección " + r.getSeccion());
                    contador++;
                }
                
                chart = org.jfree.chart.ChartFactory.createBarChart(
                    "Top 5: Préstamos por Sección", "Sección", "Total Préstamos", dataset,
                    org.jfree.chart.plot.PlotOrientation.VERTICAL, false, true, false
                );
                break;
            }
            case "Inventario de libros": {
                List<Modelo.Libro> lista = daoReportes.listarInventarioLibros(categoria);
                org.jfree.data.category.DefaultCategoryDataset dataset = new org.jfree.data.category.DefaultCategoryDataset();
                
                int contador = 0;
                for (Modelo.Libro l : lista) {
                    if (contador >= 5) break;
                    dataset.addValue(l.getCantidad(), "Cantidad", l.getTitulo());
                    contador++;
                }
                
                chart = org.jfree.chart.ChartFactory.createBarChart(
                    "Top 5: Inventario de Libros (Cantidad)", "Libros", "Unidades", dataset,
                    org.jfree.chart.plot.PlotOrientation.VERTICAL, false, true, false
                );
                break;
            }
            default: { 
                String estadoFiltro = null;
                if (filtro.equalsIgnoreCase("Prestamos Activos") || filtro.equalsIgnoreCase("Préstamos Activos")) {
                    estadoFiltro = "Activo";
                } else if (filtro.equalsIgnoreCase("Prestamos Vencidos") || filtro.equalsIgnoreCase("Préstamos Vencidos")) {
                    estadoFiltro = "Vencido";
                }
                List<Modelo.ReportePrestamo> lista = daoReportes.listarReporteAvanzado(estadoFiltro, categoria, seccion, fechaDesde, fechaHasta);
                java.util.Map<String, Integer> conteoEstados = new java.util.HashMap<>();
                for (Modelo.ReportePrestamo r : lista) {
                    String est = r.getEstado() != null ? r.getEstado() : "Desconocido";
                    conteoEstados.put(est, conteoEstados.getOrDefault(est, 0) + 1);
                }
                
                org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                for (java.util.Map.Entry<String, Integer> entry : conteoEstados.entrySet()) {
                    dataset.setValue(entry.getKey(), entry.getValue());
                }
                
                String tituloGrafico = "Préstamos (General)";
                if (estadoFiltro != null) {
                    tituloGrafico = "Préstamos Filtrados: " + filtro;
                }
                
                chart = org.jfree.chart.ChartFactory.createPieChart(
                    tituloGrafico,
                    dataset, true, true, false
                );
                break;
            }
        }
        
        if (chart != null) {
            if (chart.getPlot() instanceof org.jfree.chart.plot.CategoryPlot) {
                org.jfree.chart.plot.CategoryPlot plot = chart.getCategoryPlot();
                org.jfree.chart.renderer.category.BarRenderer renderer = new org.jfree.chart.renderer.category.BarRenderer() {
                    private final java.awt.Color[] palette = {
                        new java.awt.Color(41, 128, 185),
                        new java.awt.Color(52, 152, 219),
                        new java.awt.Color(26, 188, 156),
                        new java.awt.Color(46, 204, 113),
                        new java.awt.Color(155, 89, 182)
                    };
                    @Override
                    public java.awt.Paint getItemPaint(int row, int column) {
                        return palette[column % palette.length];
                    }
                };
                renderer.setBarPainter(new org.jfree.chart.renderer.category.StandardBarPainter());
                plot.setRenderer(renderer);
            }
            
            // Subtítulos dinámicos
            if (categoria != null && !categoria.equals("Todas las categorías")) {
                chart.addSubtitle(new org.jfree.chart.title.TextTitle(
                    "Categoría: " + categoria, 
                    new java.awt.Font("SansSerif", java.awt.Font.ITALIC, 11)
                ));
            }
            if (seccion != null && !seccion.trim().isEmpty()) {
                chart.addSubtitle(new org.jfree.chart.title.TextTitle(
                    "Sección: " + seccion.trim(), 
                    new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 11)
                ));
            }
            if (fechaDesde != null && fechaHasta !=null) {
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
                chart.addSubtitle(new org.jfree.chart.title.TextTitle(
                    "Período: " + sdf.format(fechaDesde) + " al " + sdf.format(fechaHasta), 
                    new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 11)
                ));
            }
            
            org.jfree.chart.ChartPanel chartPanel = new org.jfree.chart.ChartPanel(chart);
            chartPanel.setMouseWheelEnabled(true);
            panelContenedor.removeAll();
            panelContenedor.setLayout(new java.awt.BorderLayout());
            panelContenedor.add(chartPanel, java.awt.BorderLayout.CENTER);
            panelContenedor.validate();
            panelContenedor.repaint();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
}