package Controlador;
import Modelo.DAOEstudiante;
import Modelo.Estudiante;
import java.util.ArrayList;
import java.util.List;

public class EstudianteController {
    private DAOEstudiante dao = new DAOEstudiante();

    public EstudianteController() {
    }
public boolean existeEstudiante(String nombre, String apellido, int idExcluir) {
    return dao.existeEstudiante(nombre, apellido, idExcluir);
}
    public boolean registrar(String nombre, String apellido, String telefono, String grado, String seccion) {
        Estudiante e = new Estudiante(0, nombre, apellido, telefono, grado, seccion);
        return dao.insertar(e);
    }

    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    public boolean actualizarEstudiante(int id, String nombre, String apellido, String telefono, String grado, String seccion) {
        Estudiante e = new Estudiante(id, nombre, apellido, telefono, grado, seccion);
        return dao.actualizar(e);
    }

    public boolean eliminarEstudiante(int id) {
        return dao.eliminar(id);
    }

    public List<Estudiante> buscarEstudiante(String texto) {
        List<Estudiante> filtrada = new ArrayList<>();
        for (Estudiante e : dao.listar()) {
            if (e.getNombre().toLowerCase().contains(texto.toLowerCase()) ||
                e.getApellido().toLowerCase().contains(texto.toLowerCase()) ||
                e.getGrado().toLowerCase().contains(texto.toLowerCase())) {
                filtrada.add(e);
            }
        }
        return filtrada;
    }
}
