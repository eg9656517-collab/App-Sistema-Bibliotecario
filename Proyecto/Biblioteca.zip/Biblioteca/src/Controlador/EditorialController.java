package Controlador;

import Modelo.DAOEditorial;
import Modelo.Editorial;
import java.util.List;

public class EditorialController {
    private DAOEditorial dao = new DAOEditorial();

    public boolean registrarEditorial(String nombre, String pais) {
        Editorial nuevo = new Editorial(nombre, pais);
        return dao.insertar(nuevo);
    }

    public boolean modificarEditorial(int id, String nombre, String pais) {
        Editorial editado = new Editorial(id, nombre, pais);
        return dao.modificar(editado);
    }

    public boolean eliminarEditorial(int id) {
        return dao.eliminar(id);
    }

    public List<Editorial> obtenerEditoriales() {
        return dao.listarEditoriales();
    }
    public boolean existeNombreEditorial(String nombre, int idExcluir) {
    return dao.existeNombreEditorial(nombre, idExcluir);
}
}