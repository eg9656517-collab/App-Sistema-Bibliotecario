
package Controlador;

import Modelo.DAOUsuarioLogin;
import Modelo.UsuarioLogin;
import Modelo.DAOUsuario;
public class UsuarioLoginController {
    private DAOUsuarioLogin dao = new DAOUsuarioLogin();

    public boolean validarIngreso(String user, String pass) {
        UsuarioLogin usuarioIntentandoEntrar = new UsuarioLogin();
        usuarioIntentandoEntrar.setNombreUsuario(user);
        usuarioIntentandoEntrar.setContrasena(pass);
        return dao.autenticar(usuarioIntentandoEntrar);
    }
    public String obtenerRolUsuario(String nombreUsuario) {
    return dao.buscarRolPorNombre(nombreUsuario); 
}
}


