package Controlador;
import Modelo.DAORol;
import Modelo.Rol;
import java.util.List;

public class RolController {
    private DAORol dao = new DAORol();
    private static Rol rolActivo;

    public boolean registrarOEditar(int id, String rol, String desc, String estado) {
        if (rol.trim().isEmpty()) return false;
        Rol nuevoRol = new Rol(id, rol, desc, estado);
        return dao.guardar(nuevoRol);
    }
    public List<Rol> obtenerTodos() {
        return dao.listar();
    }
    
    public static void setRolActivo(Rol rol) {
        rolActivo = rol;
    }

    public static Rol getRolActivo() {
        return rolActivo;
    }
    public static void cerrarSesion() {
        rolActivo = null;
    }
}