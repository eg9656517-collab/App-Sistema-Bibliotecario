package Controlador;

import Modelo.DAOAutor;
import Modelo.Autor;
import java.util.List;

public class AutorController {
    private DAOAutor dao = new DAOAutor();

    public boolean registrarAutor(String nombre, String apellido) {
        Autor nuevo = new Autor(nombre, apellido);
        return dao.insertar(nuevo);
    }

    public boolean modificarAutor(int id, String nombre, String apellido) {
        Autor editado = new Autor(id, nombre, apellido);
        return dao.modificar(editado);
    }

    public boolean eliminarAutor(int id) {
        return dao.eliminar(id);
    }

    public List<Autor> obtenerAutores() {
        return dao.listarAutores();
    }
    public boolean existeAutor(String nombre, String apellido, int idExcluir) {
    return dao.existeAutor(nombre, apellido, idExcluir);
}
}