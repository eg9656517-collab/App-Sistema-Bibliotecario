package Controlador;

import Modelo.DAOPrestamo;
import Modelo.Prestamo;
import Modelo.Libro;
import Modelo.Estudiante;
import java.util.ArrayList;
import java.util.List;

public class PrestamoController {
    private DAOPrestamo daoPrestamo = new DAOPrestamo();
    private EstudianteController controlEstudiante = new EstudianteController();
    private LibroController controlLibro = new LibroController();

    public PrestamoController() {
    }

    public boolean existeEstudiante(int idEstudiante) {
        for (Estudiante e : controlEstudiante.obtenerTodos()) {
            if (e.getId() == idEstudiante) {
                return true;
            }
        }
        return false;
    }
    public boolean tienePrestamoActivo(int idEstudiante, int idLibro) {
    return daoPrestamo.tienePrestamoActivo(idEstudiante, idLibro);
}

    public Libro buscarLibroPorCodigo(int codigoLibro) {
        for (Libro l : controlLibro.obtenerTodos()) {
            if (l.getCodigo() == codigoLibro) {
                return l;
            }
        }
        return null;
    }

  public String registrarPrestamo(int idEstudiante, int codigoLibro, String fechaPres, String fechaLim) {
    if (!existeEstudiante(idEstudiante)) {
        return "ERROR_ESTUDIANTE";
    }
    Libro libro = buscarLibroPorCodigo(codigoLibro);
    if (libro == null) {
        return "ERROR_LIBRO_INEXISTENTE";
    }
    if (libro.getCantidad() <= 0) {
        return "ERROR_LIBRO_OCUPADO";
    }
    
    Prestamo nuevoPrestamo = new Prestamo(0, idEstudiante, codigoLibro, fechaPres, fechaLim, "", "Activo");
    daoPrestamo.insertar(nuevoPrestamo);
    int nuevaCantidadPrestamo = libro.getCantidad() - 1;
    String nuevoEstadoPrestamo = (nuevaCantidadPrestamo == 0) ? "Prestado" : "Disponible";
    libro.setDisponibilidad(nuevoEstadoPrestamo);
 
    controlLibro.actualizarLibro(
        libro.getCodigo(), 
        libro.getTitulo(), 
        libro.getAutor(), 
        libro.getCategoria(), 
        libro.getEditorial(), 
        libro.getAnoPublicacion(), 
        nuevoEstadoPrestamo, 
        libro.getUbicacion(),
        nuevaCantidadPrestamo
    );

    return "OK";
}
public boolean eliminarPrestamo(int idPrestamo) {
    DAOPrestamo dao = new DAOPrestamo(); 
    return dao.eliminar(idPrestamo);
}
   public boolean procesarDevolucion(int idPrestamo, String fechaDevolucion) {
    for (Prestamo p : daoPrestamo.listar()) {
        if (p.getIdPrestamo() == idPrestamo && p.getEstado().equalsIgnoreCase("Activo")) {
            p.setEstado("Devuelto");
            p.setFechaDevolucion(fechaDevolucion);
            daoPrestamo.actualizar(p);

            Libro libro = buscarLibroPorCodigo(p.getCodigoLibro());
            if (libro != null) {
                int nuevaCantidadDevolucion = libro.getCantidad() + 1;
                String nuevoEstadoDevolucion = "Disponible";
                controlLibro.actualizarLibro(
                    libro.getCodigo(), 
                    libro.getTitulo(), 
                    libro.getAutor(), 
                    libro.getCategoria(), 
                    libro.getEditorial(), 
                    libro.getAnoPublicacion(), 
                    nuevoEstadoDevolucion, 
                    libro.getUbicacion(),
                    nuevaCantidadDevolucion 
                );
            }
            return true;
        }
    }
    return false;
}

    public List<Prestamo> obtenerTodos() {
        return daoPrestamo.listar();
    }

   public List<Prestamo> buscarPrestamos(String texto) {
    if (texto == null || texto.trim().isEmpty()) {
        return daoPrestamo.listar();
    }
    return daoPrestamo.buscar(texto);
}
    
   public List<Prestamo> filtrarHistorial(String nombreEstudStr, String tituloLibroBusqueda, String fechaStr, String estadoStr) {
    List<Prestamo> filtrada = new ArrayList<>();
    String estudBusqueda = nombreEstudStr.trim().toLowerCase(); // Ahora buscamos texto en minúsculas
    String libroBusqueda = tituloLibroBusqueda.trim().toLowerCase();
    String fechaBusqueda = fechaStr.trim();
    String estadoBusqueda = estadoStr.trim();
    java.time.format.DateTimeFormatter formatoMySQL = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
    java.time.format.DateTimeFormatter formatoUI = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
    Controlador.EstudianteController controlEstudiante = new Controlador.EstudianteController();
    for (Prestamo p : daoPrestamo.listar()) {
        String nombreEstudianteReal = "";
        for (Modelo.Estudiante est : controlEstudiante.obtenerTodos()) {
            if (est.getId() == p.getIdEstudiante()) {
                nombreEstudianteReal = (est.getNombre() + " " + est.getApellido()).toLowerCase();
                break;
            }
        }

        String prestamoFechaConvertida = p.getFechaPrestamo(); 
        if (prestamoFechaConvertida != null && prestamoFechaConvertida.contains("-")) {
            try {
                prestamoFechaConvertida = java.time.LocalDate.parse(prestamoFechaConvertida.trim(), formatoMySQL).format(formatoUI);
            } catch (Exception e) {
                prestamoFechaConvertida = p.getFechaPrestamo();
            }
        }

        String tituloLibroReal = controlLibro.obtenerTituloPorCodigo(p.getCodigoLibro());
        if (tituloLibroReal == null) tituloLibroReal = "";
        tituloLibroReal = tituloLibroReal.toLowerCase();
        boolean coincideEstudiante = estudBusqueda.isEmpty() || nombreEstudianteReal.contains(estudBusqueda);
        boolean coincideLibro = libroBusqueda.isEmpty() || tituloLibroReal.contains(libroBusqueda);
        boolean coincideFecha = fechaBusqueda.isEmpty() || (prestamoFechaConvertida != null && prestamoFechaConvertida.contains(fechaBusqueda));
        boolean coincideEstado = estadoBusqueda.isEmpty() || p.getEstado().equalsIgnoreCase(estadoBusqueda);
        
        if (coincideEstudiante && coincideLibro && coincideFecha && coincideEstado) {
            filtrada.add(p);
        }
    }
    return filtrada;
}

   public boolean renovarPrestamo(int idPrestamo, String nuevaFechaLimite) {
    for (Prestamo p : daoPrestamo.listar()) {
        if (p.getIdPrestamo() == idPrestamo) {
            p.setFechaLimite(nuevaFechaLimite);
            return daoPrestamo.actualizar(p); 
        }
    }
    return false;
}
    public List<Prestamo> obtenerPrestamosActivos(String filtroBusqueda) {
    List<Prestamo> activosFiltrados = new ArrayList<>();
    String busqueda = filtroBusqueda.trim().toLowerCase();
    Controlador.LibroController controlLibro = new Controlador.LibroController();
    Controlador.EstudianteController controlEstudiante = new Controlador.EstudianteController();
    
    java.util.List<Modelo.Estudiante> listaEstudiantes = controlEstudiante.obtenerTodos();
    
    for (Prestamo p : daoPrestamo.listar()) {
        if (p.getEstado().equalsIgnoreCase("Activo")) {
            if (busqueda.isEmpty()) {
                activosFiltrados.add(p);
            } else {
                String tituloLibro = controlLibro.obtenerTituloPorCodigo(p.getCodigoLibro());
                if (tituloLibro == null) tituloLibro = "";
                tituloLibro = tituloLibro.toLowerCase();
                String nombreEstudiante = "";
                for (Modelo.Estudiante est : listaEstudiantes) {
                    if (est.getId() == p.getIdEstudiante()) {
                        nombreEstudiante = (est.getNombre() + " " + est.getApellido()).toLowerCase();
                        break;
                    }
                }
                if (tituloLibro.contains(busqueda) || nombreEstudiante.contains(busqueda)) {
                    activosFiltrados.add(p);
                }
            }
        }
    }
    return activosFiltrados;
}
}