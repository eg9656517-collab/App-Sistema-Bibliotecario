package Modelo;

public class ReporteLibroPopular {
    private String titulo;
    private String autor;
    private String categoria;
    private int totalPrestamos;

    public ReporteLibroPopular(String titulo, String autor, String categoria, int totalPrestamos) {
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
        this.totalPrestamos = totalPrestamos;
    }

    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public String getCategoria() { return categoria; }
    public int getTotalPrestamos() { return totalPrestamos; }
}