package Modelo;

import Conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOReportes {

    // 1. Reporte general de préstamos (Ordenado por fecha más reciente)
    public List<ReportePrestamo> listarReportePrestamos(String estadoFiltro) throws SQLException {
        List<ReportePrestamo> lista = new ArrayList<>();
        
        String sql = "SELECT p.id_prestamo, l.titulo, CONCAT(e.nombre, ' ', e.apellido) AS estudiante, " +
                     "e.seccion, p.fecha_prestamo, p.fecha_limite, p.estado " +
                     "FROM prestamo p " +
                     "INNER JOIN libro l ON p.id_libro = l.id_libro " +
                     "INNER JOIN estudiante e ON p.id_estudiante = e.id_estudiante";
        
        if (estadoFiltro != null && !estadoFiltro.equals("Todos los prestamos")) {
            sql += " WHERE p.estado = ?";
        }
        
        sql += " ORDER BY p.fecha_prestamo DESC";
        
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            if (estadoFiltro != null && !estadoFiltro.equals("Todos los prestamos")) {
                ps.setString(1, estadoFiltro);
            }
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ReportePrestamo r = new ReportePrestamo(
                        rs.getInt("id_prestamo"),
                        rs.getString("titulo"),
                        rs.getString("estudiante"),
                        rs.getString("seccion"),
                        rs.getDate("fecha_prestamo").toLocalDate(),
                        rs.getDate("fecha_limite").toLocalDate(),
                        rs.getString("estado")
                    );
                    lista.add(r);
                }
            }
        }
        return lista;
    }
    
    // 2. Reporte de Libros Más Prestados 
    public List<ReporteLibroPopular> listarLibrosMasPrestadosFiltrados(String categoria, java.util.Date fechaDesde, java.util.Date fechaHasta) throws SQLException {
        List<ReporteLibroPopular> lista = new ArrayList<>();
        
        StringBuilder sql = new StringBuilder(
            "SELECT l.titulo, l.autor, l.categoria, COUNT(p.id_prestamo) AS total " +
            "FROM prestamo p " +
            "INNER JOIN libro l ON p.id_libro = l.id_libro WHERE 1=1"
        );
        
        List<Object> parametros = new ArrayList<>();
        
        if (categoria != null && !categoria.equals("Todas las categorías")) {
            sql.append(" AND l.categoria = ?");
            parametros.add(categoria);
        }
        
        if (fechaDesde != null) {
            sql.append(" AND p.fecha_prestamo >= ?");
            parametros.add(new java.sql.Date(fechaDesde.getTime()));
        }
        
        if (fechaHasta != null) {
            sql.append(" AND p.fecha_prestamo <= ?");
            parametros.add(new java.sql.Date(fechaHasta.getTime()));
        }
        
        sql.append(" GROUP BY l.id_libro, l.titulo, l.autor, l.categoria ORDER BY total DESC");
        
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ReporteLibroPopular r = new ReporteLibroPopular(
                        rs.getString("titulo"),
                        rs.getString("autor"),
                        rs.getString("categoria"),
                        rs.getInt("total")
                    );
                    lista.add(r);
                }
            }
        }
        return lista;
    }

    // 3. Reporte Avanzado de Préstamos 
    public List<ReportePrestamo> listarReporteAvanzado(String estado, String categoria, String seccion, java.util.Date fechaDesde, java.util.Date fechaHasta) throws SQLException {
        List<ReportePrestamo> lista = new ArrayList<>();
        
        StringBuilder sql = new StringBuilder(
            "SELECT p.id_prestamo, l.titulo, CONCAT(e.nombre, ' ', e.apellido) AS estudiante, " +
            "e.seccion, p.fecha_prestamo, p.fecha_limite, p.estado " +
            "FROM prestamo p " +
            "INNER JOIN libro l ON p.id_libro = l.id_libro " +
            "INNER JOIN estudiante e ON p.id_estudiante = e.id_estudiante WHERE 1=1"
        );
        
        List<Object> parametros = new ArrayList<>();
        
        if (estado != null && !estado.isEmpty()) {
            sql.append(" AND p.estado = ?");
            parametros.add(estado);
        }
        
        if (categoria != null && !categoria.equals("Todas las categorías")) {
            sql.append(" AND l.categoria = ?");
            parametros.add(categoria);
        }
        
        if (seccion != null && !seccion.trim().isEmpty()) {
            sql.append(" AND e.seccion LIKE ?");
            parametros.add("%" + seccion.trim() + "%");
        }
        
        if (fechaDesde != null) {
            sql.append(" AND p.fecha_prestamo >= ?");
            parametros.add(new java.sql.Date(fechaDesde.getTime()));
        }
        
        if (fechaHasta != null) {
            sql.append(" AND p.fecha_prestamo <= ?");
            parametros.add(new java.sql.Date(fechaHasta.getTime()));
        }
        
        sql.append(" ORDER BY p.fecha_prestamo DESC");
        
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ReportePrestamo r = new ReportePrestamo(
                        rs.getInt("id_prestamo"),
                        rs.getString("titulo"),
                        rs.getString("estudiante"),
                        rs.getString("seccion"),
                        rs.getDate("fecha_prestamo").toLocalDate(),
                        rs.getDate("fecha_limite").toLocalDate(),
                        rs.getString("estado")
                    );
                    lista.add(r);
                }
            }
        }
        return lista;
    }

    // 4. Reporte de Secciones con más Préstamos
    public List<ReporteSeccionPopular> listarSeccionesMasPrestamos(java.util.Date fechaDesde, java.util.Date fechaHasta) throws SQLException {
        List<ReporteSeccionPopular> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT e.seccion, COUNT(p.id_prestamo) AS total " +
            "FROM prestamo p " +
            "INNER JOIN estudiante e ON p.id_estudiante = e.id_estudiante WHERE 1=1"
        );
        
        List<Object> parametros = new ArrayList<>();
        if (fechaDesde != null) {
            sql.append(" AND p.fecha_prestamo >= ?");
            parametros.add(new java.sql.Date(fechaDesde.getTime()));
        }
        if (fechaHasta != null) {
            sql.append(" AND p.fecha_prestamo <= ?");
            parametros.add(new java.sql.Date(fechaHasta.getTime()));
        }
        
        sql.append(" GROUP BY e.seccion ORDER BY total DESC");
        
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new ReporteSeccionPopular(
                        rs.getString("seccion"),
                        rs.getInt("total")
                    ));
                }
            }
        }
        return lista;
    }

    // 5. Reporte de Inventario de Libros 
    public List<Modelo.Libro> listarInventarioLibros(String categoria) throws SQLException {
        List<Modelo.Libro> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM libro WHERE 1=1");
        
        List<Object> parametros = new ArrayList<>();
        if (categoria != null && !categoria.equals("Todas las categorías")) {
            sql.append(" AND categoria = ?");
            parametros.add(categoria);
        }
        
        sql.append(" ORDER BY cantidad DESC");
        
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Modelo.Libro lib = new Modelo.Libro();
                    lib.setCodigo(rs.getInt("id_libro"));
                    lib.setTitulo(rs.getString("titulo"));
                    lib.setAutor(rs.getString("autor"));
                    lib.setCategoria(rs.getString("categoria"));
                    lib.setEditorial(rs.getString("editorial"));
                    lib.setAnoPublicacion(rs.getString("anio_publicacion"));
                    lib.setDisponibilidad(rs.getString("disponibilidad"));
                    lib.setUbicacion(rs.getString("ubicacion"));
                    lib.setCantidad(rs.getInt("cantidad"));
                    
                    lista.add(lib);
                }
            }
        }
        return lista;
    }
}