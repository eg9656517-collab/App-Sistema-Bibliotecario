package Modelo;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOLibro {

    public DAOLibro() {
    }

    public boolean insertar(Libro l) {
        Connection con = null;
        CallableStatement cs = null;
        boolean insertado = false;
        String sql = "{call sp_insertar_libro(?, ?, ?, ?, ?, ?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, l.getTitulo());
                cs.setString(2, l.getAutor());
                cs.setString(3, l.getCategoria());
                cs.setString(4, l.getEditorial());
                
                int anioEntero = 0;
                if (l.getAnoPublicacion() != null && !l.getAnoPublicacion().trim().isEmpty()) {
                    anioEntero = Integer.parseInt(l.getAnoPublicacion().trim());
                }
                cs.setInt(5, anioEntero); 
                cs.setString(6, l.getDisponibilidad());
                cs.setString(7, l.getUbicacion());
                cs.setInt(8, l.getCantidad());
                
                int filasAfectadas = cs.executeUpdate();
                if (filasAfectadas > 0) {
                    insertado = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al insertar libro: " + ex.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error de formato al convertir el año al insertar: " + e.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return insertado;
    }

    public List<Libro> listar() {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        List<Libro> lista = new ArrayList<>();
        String sql = "{call sp_listar_libros()}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                rs = cs.executeQuery();
                
                while (rs.next()) {
                    Libro l = new Libro();
                    l.setCodigo(rs.getInt("id_libro")); 
                    l.setTitulo(rs.getString("titulo"));
                    l.setAutor(rs.getString("autor"));
                    l.setCategoria(rs.getString("categoria"));
                    l.setEditorial(rs.getString("editorial"));
                    l.setAnoPublicacion(rs.getString("anio_publicacion"));
                    l.setDisponibilidad(rs.getString("disponibilidad"));
                    l.setUbicacion(rs.getString("ubicacion"));
                    l.setCantidad(rs.getInt("cantidad"));
                    
                    lista.add(l);
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar libros: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, rs);
        }
        return lista;
    }

    public boolean actualizar(Libro l) {
        Connection con = null;
        CallableStatement cs = null;
        boolean actualizado = false;
        String sql = "{call sp_actualizar_libro(?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, l.getTitulo());
                cs.setString(2, l.getAutor());
                cs.setString(3, l.getCategoria());
                cs.setString(4, l.getEditorial());
                
                int anioEntero = 0;
                if (l.getAnoPublicacion() != null && !l.getAnoPublicacion().trim().isEmpty()) {
                    anioEntero = Integer.parseInt(l.getAnoPublicacion().trim());
                }
                cs.setInt(5, anioEntero); 
                cs.setString(6, l.getDisponibilidad());
                cs.setString(7, l.getUbicacion());
                cs.setInt(8, l.getCantidad());
                cs.setInt(9, l.getCodigo());
                
                int filasAfectadas = cs.executeUpdate();
                if (filasAfectadas > 0) {
                    actualizado = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al actualizar libro: " + ex.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error de formato al convertir el año en el DAO: " + e.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return actualizado;
    }

    public boolean eliminar(int codigo) {
        Connection con = null;
        CallableStatement cs = null;
        boolean eliminado = false;
        String sql = "{call sp_eliminar_libro(?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setInt(1, codigo);
                
                int filasAfectadas = cs.executeUpdate();
                if (filasAfectadas > 0) {
                    eliminado = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al eliminar libro: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return eliminado;
    }

    public boolean existeLibroPorTitulo(String titulo, int idExcluir) {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        boolean existe = false;
        String sql = "{call sp_existe_libro_por_titulo(?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, titulo.trim());
                cs.setInt(2, idExcluir);

                rs = cs.executeQuery();
                if (rs.next() && rs.getInt("total") > 0) {
                    existe = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al verificar duplicado de título: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, rs);
        }
        return existe;
    }

    private void cerrarRecursos(Connection con, AutoCloseable ps, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (Exception ex) {
            System.out.println("Error al cerrar flujos JDBC de Libro: " + ex.getMessage());
        }
    }
}