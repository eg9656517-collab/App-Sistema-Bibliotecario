package Modelo;

public class UsuarioLogin {
    private int id_usuario;
    private String nombre;
    private String apellido;
    private String nombreUsuario;
    private String contrasena;
    private String rol;
    private static String usuarioDb;
    private static String passwordDb;

    public UsuarioLogin() {
    }

    public int getId_usuario() { return id_usuario; }
    public void setId_usuario(int id_usuario) { this.id_usuario = id_usuario; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    // Métodos estáticos para gestionar las credenciales de la Base de Datos
    public static void setCredenciales(String user, String pass) {
        usuarioDb = user;
        passwordDb = pass;
    }

    public static String getUsuarioDb() { return usuarioDb; }
    public static String getPasswordDb() { return passwordDb; }
}