package Modelo;
public class Rol {
    private int idRol;
    private String nombreRol; 
    private String descripcion;
    private String estado; 

    public Rol(int idRol, String nombreRol, String descripcion, String estado) {
        this.idRol = idRol;
        this.nombreRol = nombreRol;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    public int getId() { return idRol; }
    public void setId(int id) { this.idRol = id; }
    public String getNombreRol() { return nombreRol; }
    public void setNombreRol(String nombreRol) { this.nombreRol = nombreRol; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}