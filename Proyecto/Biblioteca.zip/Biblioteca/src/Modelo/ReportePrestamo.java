package Modelo;

import java.time.LocalDate;

public class ReportePrestamo {
    private int idPrestamo;
    private String libro;
    private String estudiante;
    private String seccion;
    private LocalDate fechaPrestamo;
    private LocalDate fechaLimite;
    private String estado;

    public ReportePrestamo(int idPrestamo, String libro, String estudiante, String seccion, 
                           LocalDate fechaPrestamo, LocalDate fechaLimite, String estado) {
        this.idPrestamo = idPrestamo;
        this.libro = libro;
        this.estudiante = estudiante;
        this.seccion = seccion;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaLimite = fechaLimite;
        this.estado = estado;
    }

    // Getters
    public int getIdPrestamo() { return idPrestamo; }
    public String getLibro() { return libro; }
    public String getEstudiante() { return estudiante; }
    public String getSeccion() { return seccion; }
    public LocalDate getFechaPrestamo() { return fechaPrestamo; }
    public LocalDate getFechaLimite() { return fechaLimite; }
    public String getEstado() { return estado; }
}