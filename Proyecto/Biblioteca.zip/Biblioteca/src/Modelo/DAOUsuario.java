package Modelo;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOUsuario {

    public DAOUsuario() {
    }

    public void guardar(Usuario u) {
        Connection con = null;
        CallableStatement cs = null;
        String sql = "{call sp_guardar_usuario(?, ?, ?, ?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, u.getNombreCompleto());
                cs.setString(2, u.getNombreUsuario());
                cs.setString(3, u.getCorreo());
                cs.setString(4, u.getTelefono());
                cs.setString(5, u.getRol());
                cs.setString(6, u.getContrasena());
                
                cs.executeUpdate();
            }
        } catch (SQLException ex) {
            System.out.println("Error al guardar usuario en BD: " + ex.getMessage());
        } finally {
            cerrarFlujos(con, cs, null);
        }
    }

    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        String sql = "{call sp_listar_usuarios()}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                rs = cs.executeQuery();

                while (rs.next()) {
                    String nombreCompleto = rs.getString("nombre");

                    Usuario u = new Usuario(
                        rs.getInt("id_usuario"),
                        nombreCompleto,
                        rs.getString("nombre_usuario"),
                        rs.getString("contrasena"),
                        rs.getString("correo"),
                        rs.getString("telefono"),
                        rs.getString("rol")
                    );
                    lista.add(u);
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar usuarios desde BD: " + ex.getMessage());
        } finally {
            cerrarFlujos(con, cs, rs);
        }
        return lista;
    }

    public boolean existeUsuario(String user) {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        String sql = "{call sp_existe_usuario(?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, user);
                rs = cs.executeQuery();
                if (rs.next()) {
                    return true; 
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al validar existencia de usuario: " + ex.getMessage());
        } finally {
            cerrarFlujos(con, cs, rs);
        }
        return false;
    }

    public void actualizar(Usuario u) {
        Connection con = null;
        CallableStatement cs = null;
        String sql = "{call sp_actualizar_usuario(?, ?, ?, ?, ?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, u.getNombreCompleto());
                cs.setString(2, u.getNombreUsuario());
                cs.setString(3, u.getCorreo());
                cs.setString(4, u.getTelefono());
                cs.setString(5, u.getRol());
                cs.setString(6, u.getContrasena());
                cs.setInt(7, u.getId()); 
                
                cs.executeUpdate();
            }
        } catch (SQLException ex) {
            System.out.println("Error al actualizar usuario en Base de datos: " + ex.getMessage());
        } finally {
            cerrarFlujos(con, cs, null);
        }
    }

    public void eliminar(int id) {
        Connection con = null;
        CallableStatement cs = null;
        String sql = "{call sp_eliminar_usuario(?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setInt(1, id);
                
                cs.executeUpdate();
            }
        } catch (SQLException ex) {
            System.out.println("Error al eliminar usuario en BD: " + ex.getMessage());
        } finally {
            cerrarFlujos(con, cs, null);
        }
    }

    private void cerrarFlujos(Connection con, AutoCloseable cs, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (cs != null) cs.close();
            if (con != null) con.close();
        } catch (Exception e) {
            System.out.println("Error al cerrar recursos JDBC: " + e.getMessage());
        }
    }
}