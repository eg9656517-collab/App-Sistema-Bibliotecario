package Modelo;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOAutor {

    public boolean insertar(Autor autor) {
        String sql = "{call sp_insertar_autor(?, ?)}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setString(1, autor.getNombre());
            cs.setString(2, autor.getApellido());
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al insertar autor: " + e.getMessage());
            return false;
        }
    }

    public boolean modificar(Autor autor) {
        String sql = "{call sp_modificar_autor(?, ?, ?)}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setString(1, autor.getNombre());
            cs.setString(2, autor.getApellido());
            cs.setInt(3, autor.getId_autor());
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al modificar autor: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "{call sp_eliminar_autor(?)}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setInt(1, id);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al eliminar autor: " + e.getMessage());
            return false;
        }
    }

    public List<Autor> listarAutores() {
        List<Autor> lista = new ArrayList<>();
        String sql = "{call sp_listar_autores()}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            
            while (rs.next()) {
                Autor autor = new Autor();
                autor.setId_autor(rs.getInt("id_autor"));
                autor.setNombre(rs.getString("nombre"));
                autor.setApellido(rs.getString("apellido"));
                lista.add(autor);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar autores: " + e.getMessage());
        }
        return lista;
    }

    public boolean existeAutor(String nombre, String apellido, int idExcluir) {
        String sql = "{call sp_existe_autor(?, ?, ?)}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setString(1, nombre.trim());
            cs.setString(2, apellido.trim());
            cs.setInt(3, idExcluir);
            
            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total") > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar duplicidad de autor: " + e.getMessage());
        }
        return false;
    }
}