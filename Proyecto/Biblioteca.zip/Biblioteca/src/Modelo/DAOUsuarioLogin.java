package Modelo;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOUsuarioLogin {
    
    public boolean autenticar(UsuarioLogin user) {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        boolean existe = false;
        String sql = "{call sp_autenticar_usuario(?, ?)}";

        try {
            con = ConexionBD.conectar(); 
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, user.getNombreUsuario()); 
                cs.setString(2, user.getContrasena()); 
                rs = cs.executeQuery(); 
                if (rs != null && rs.next()) {
                    existe = true;
                    user.setNombre(rs.getString("nombre"));
                    user.setRol(rs.getString("rol"));
                }
            }
        } catch (SQLException e) {
            System.out.println("ERROR CRÍTICO DE SQL EN EL DAO: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cerrarFlujos(con, cs, rs);
        }
        
        return existe; 
    }

    public String buscarRolPorNombre(String nombreUsuario) {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        String rolEncontrado = "Estudiante";
        String sql = "{call sp_buscar_rol_por_usuario(?)}";
        
        try {
            con = ConexionBD.conectar(); 
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, nombreUsuario);
                rs = cs.executeQuery();
                
                if (rs.next()) {
                    rolEncontrado = rs.getString("rol");
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener rol del usuario: " + ex.getMessage());
        } finally {
            cerrarFlujos(con, cs, rs);
        }
        return rolEncontrado;
    }

    private void cerrarFlujos(Connection con, AutoCloseable cs, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (cs != null) cs.close();
            if (con != null) con.close();
        } catch (Exception e) {
            System.out.println("Error al cerrar recursos JDBC: " + e.getMessage());
        }
    }
}