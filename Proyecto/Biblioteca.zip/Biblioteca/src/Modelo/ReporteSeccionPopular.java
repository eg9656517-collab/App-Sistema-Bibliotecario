package Modelo;

public class ReporteSeccionPopular {
    private String Seccion;
    private int totalPrestamos;

    public ReporteSeccionPopular(String Seccion, int totalPrestamos) {
        this.Seccion = Seccion;
        this.totalPrestamos = totalPrestamos;
    }

    public String getSeccion() {
        return Seccion;
    }

    public void setSeccion(String Seccion) {
        this.Seccion = Seccion;
    }

    public int getTotalPrestamos() {
        return totalPrestamos;
    }

    public void setTotalPrestamos(int totalPrestamos) {
        this.totalPrestamos = totalPrestamos;
    }
}