package Modelo;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOEditorial {

    public boolean insertar(Editorial editorial) {
        String sql = "{call sp_insertar_editorial(?, ?)}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setString(1, editorial.getNombre());
            cs.setString(2, editorial.getPais());
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al insertar editorial: " + e.getMessage());
            return false;
        }
    }

    public boolean modificar(Editorial editorial) {
        String sql = "{call sp_modificar_editorial(?, ?, ?)}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setString(1, editorial.getNombre());
            cs.setString(2, editorial.getPais());
            cs.setInt(3, editorial.getId_editorial());
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al modificar editorial: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "{call sp_eliminar_editorial(?)}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setInt(1, id);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al eliminar editorial: " + e.getMessage());
            return false;
        }
    }

    public List<Editorial> listarEditoriales() {
        List<Editorial> lista = new ArrayList<>();
        String sql = "{call sp_listar_editoriales()}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            
            while (rs.next()) {
                Editorial ed = new Editorial();
                ed.setId_editorial(rs.getInt("id_editorial"));
                ed.setNombre(rs.getString("nombre"));
                ed.setPais(rs.getString("pais"));
                lista.add(ed);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar editoriales: " + e.getMessage());
        }
        return lista;
    }

    public boolean existeNombreEditorial(String nombre, int idExcluir) {
        String sql = "{call sp_existe_nombre_editorial(?, ?)}";
        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setString(1, nombre.trim());
            cs.setInt(2, idExcluir);
            
            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total") > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar duplicidad de editorial: " + e.getMessage());
        }
        return false;
    }
}