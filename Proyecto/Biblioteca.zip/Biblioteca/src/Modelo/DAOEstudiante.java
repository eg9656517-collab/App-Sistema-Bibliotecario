package Modelo;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOEstudiante {

    public DAOEstudiante() {
    }

    public boolean insertar(Estudiante e) {
        Connection con = null;
        CallableStatement cs = null;
        boolean insertado = false;
        String sql = "{call sp_insertar_estudiante(?, ?, ?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, e.getNombre());
                cs.setString(2, e.getApellido());
                cs.setString(3, e.getTelefono());
                cs.setString(4, e.getGrado());
                cs.setString(5, e.getSeccion());
                
                int filasAfectadas = cs.executeUpdate();
                if (filasAfectadas > 0) {
                    insertado = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al insertar estudiante: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return insertado;
    }

    public boolean existeEstudiante(String nombre, String apellido, int idExcluir) {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        boolean existe = false;
        String sql = "{call sp_existe_estudiante(?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, nombre.trim());
                cs.setString(2, apellido.trim());
                cs.setInt(3, idExcluir);
                
                rs = cs.executeQuery();
                if (rs.next() && rs.getInt("total") > 0) {
                    existe = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al verificar duplicados de estudiante: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, rs);
        }
        return existe;
    }

    public List<Estudiante> listar() {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        List<Estudiante> lista = new ArrayList<>();
        String sql = "{call sp_listar_estudiantes()}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                rs = cs.executeQuery();
                
                while (rs.next()) {
                    Estudiante e = new Estudiante();
                    e.setId(rs.getInt("id_estudiante")); 
                    e.setNombre(rs.getString("nombre"));
                    e.setApellido(rs.getString("apellido"));
                    e.setTelefono(rs.getString("telefono"));
                    e.setGrado(rs.getString("grado"));
                    e.setSeccion(rs.getString("seccion"));
                    
                    lista.add(e);
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar estudiantes: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, rs);
        }
        return lista;
    }

    public boolean actualizar(Estudiante e) {
        Connection con = null;
        CallableStatement cs = null;
        boolean actualizado = false;
        String sql = "{call sp_actualizar_estudiante(?, ?, ?, ?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, e.getNombre());
                cs.setString(2, e.getApellido());
                cs.setString(3, e.getTelefono());
                cs.setString(4, e.getGrado());
                cs.setString(5, e.getSeccion());
                cs.setInt(6, e.getId());
                
                int filasAfectadas = cs.executeUpdate();
                if (filasAfectadas > 0) {
                    actualizado = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al actualizar estudiante: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return actualizado;
    }

    public boolean eliminar(int id) {
        Connection con = null;
        CallableStatement cs = null;
        boolean eliminado = false;
        String sql = "{call sp_eliminar_estudiante(?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setInt(1, id);
                
                int filasAfectadas = cs.executeUpdate();
                if (filasAfectadas > 0) {
                    eliminado = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al eliminar estudiante: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return eliminado;
    }

    private void cerrarRecursos(Connection con, AutoCloseable ps, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (Exception ex) {
            System.out.println("Error al cerrar flujos JDBC: " + ex.getMessage());
        }
    }
}