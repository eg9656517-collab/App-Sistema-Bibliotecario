package Modelo;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOCategoria {

    public boolean insertar(Categoria cat) {
        String sql = "{call sp_insertar_categoria(?, ?)}";

        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setString(1, cat.getNombre());
            cs.setString(2, cat.getDescripcion());

            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al insertar categoría: " + e.getMessage());
            return false;
        }
    }

    public List<Categoria> listarCategorias() {
        List<Categoria> lista = new ArrayList<>();
        String sql = "{call sp_listar_categorias()}";

        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {
                Categoria cat = new Categoria();
                cat.setId_categoria(rs.getInt("id_categoria"));
                cat.setNombre(rs.getString("nombre"));
                cat.setDescripcion(rs.getString("descripcion"));
                lista.add(cat);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar categorías: " + e.getMessage());
        }
        return lista;
    }

    public boolean modificar(Categoria cat) {
        String sql = "{call sp_modificar_categoria(?, ?, ?)}";

        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setString(1, cat.getNombre());
            cs.setString(2, cat.getDescripcion());
            cs.setInt(3, cat.getId_categoria());

            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al modificar categoría en DAO: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "{call sp_eliminar_categoria(?)}";

        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, id);

            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al eliminar categoría en DAO: " + e.getMessage());
            return false;
        }
    }

    public boolean existeNombreCategoria(String nombre, int idExcluir) {
        String sql = "{call sp_existe_nombre_categoria(?, ?)}";

        try (Connection con = ConexionBD.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setString(1, nombre.trim());
            cs.setInt(2, idExcluir);

            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total") > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar duplicidad de categoría: " + e.getMessage());
        }
        return false;
    }
}