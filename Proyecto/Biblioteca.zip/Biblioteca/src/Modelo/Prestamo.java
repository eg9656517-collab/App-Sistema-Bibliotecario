package Modelo;
public class Prestamo {
    private int idPrestamo;
    private int idEstudiante; 
    private int codigoLibro; 
    private String fechaPrestamo;
    private String fechaLimite;
    private String fechaDevolucion;
    private String estado;
private String tituloLibro;
    public Prestamo() {
    }

    public Prestamo(int idPrestamo, int idEstudiante, int codigoLibro, String fechaPrestamo, String fechaLimite, String fechaDevolucion, String estado) {
        this.idPrestamo = idPrestamo;
        this.idEstudiante = idEstudiante;
        this.codigoLibro = codigoLibro;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaLimite = fechaLimite;
        this.fechaDevolucion = fechaDevolucion;
        this.estado = estado;
    }

    public int getIdPrestamo() { return idPrestamo; }
    public void setIdPrestamo(int idPrestamo) { this.idPrestamo = idPrestamo; }
public String getTituloLibro() {
    return tituloLibro;
}
public void setTituloLibro(String tituloLibro) {
    this.tituloLibro = tituloLibro;
}
    public int getIdEstudiante() { return idEstudiante; }
    public void setIdEstudiante(int idEstudiante) { this.idEstudiante = idEstudiante; }

    public int getCodigoLibro() { return codigoLibro; }
    public void setCodigoLibro(int codigoLibro) { this.codigoLibro = codigoLibro; }

    public String getFechaPrestamo() { return fechaPrestamo; }
    public void setFechaPrestamo(String fechaPrestamo) { this.fechaPrestamo = fechaPrestamo; }

    public String getFechaLimite() { return fechaLimite; }
    public void setFechaLimite(String fechaLimite) { this.fechaLimite = fechaLimite; }

    public String getFechaDevolucion() { return fechaDevolucion; }
    public void setFechaDevolucion(String fechaDevolucion) { this.fechaDevolucion = fechaDevolucion; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
