package Modelo;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOPrestamo {

    public boolean insertar(Prestamo p) {
        Connection con = null;
        CallableStatement cs = null;
        boolean insertado = false;
        String sql = "{call sp_insertar_prestamo(?, ?, ?, ?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setInt(1, p.getCodigoLibro());
                cs.setInt(2, p.getIdEstudiante());
                cs.setString(3, convertirFechaAMySQL(p.getFechaPrestamo()));
                cs.setString(4, convertirFechaAMySQL(p.getFechaLimite()));
                
                if (p.getFechaDevolucion() == null || p.getFechaDevolucion().trim().isEmpty()) {
                    cs.setNull(5, java.sql.Types.DATE);
                } else {
                    cs.setString(5, convertirFechaAMySQL(p.getFechaDevolucion()));
                }
                
                cs.setString(6, p.getEstado() != null ? p.getEstado() : "Activo");
                
                int filas = cs.executeUpdate();
                if (filas > 0) insertado = true;
            }
        } catch (SQLException ex) {
            System.out.println(" Error al insertar préstamo: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return insertado;
    }

    public List<Prestamo> listar() {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        List<Prestamo> lista = new ArrayList<>();
        String sql = "{call sp_listar_prestamos()}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                rs = cs.executeQuery();
                
                while (rs.next()) {
                    Prestamo p = new Prestamo();
                    p.setIdPrestamo(rs.getInt("id_prestamo"));
                    p.setCodigoLibro(rs.getInt("id_libro"));
                    p.setIdEstudiante(rs.getInt("id_estudiante"));
                    p.setFechaPrestamo(rs.getString("fecha_prestamo"));
                    p.setFechaLimite(rs.getString("fecha_limite"));
                    String fDev = rs.getString("fecha_devolucion");
                    p.setFechaDevolucion(fDev == null ? "" : fDev);
                    p.setEstado(rs.getString("estado"));
                    lista.add(p);
                }
            }
        } catch (SQLException ex) {
            System.out.println("🚨 Error al listar préstamos: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, rs);
        }
        return lista;
    }

    public List<Prestamo> buscar(String textoBusqueda) {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        List<Prestamo> lista = new ArrayList<>();
        String sql = "{call sp_buscar_prestamos(?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setString(1, textoBusqueda);
                rs = cs.executeQuery();

                while (rs.next()) {
                    Prestamo p = new Prestamo();
                    p.setIdPrestamo(rs.getInt("id_prestamo"));
                    p.setIdEstudiante(rs.getInt("id_estudiante"));
                    p.setCodigoLibro(rs.getInt("id_libro"));
                    p.setFechaPrestamo(rs.getString("fecha_prestamo"));
                    p.setFechaLimite(rs.getString("fecha_limite"));
                    
                    String fDev = rs.getString("fecha_devolucion");
                    p.setFechaDevolucion(fDev != null ? fDev : "");
                    
                    p.setEstado(rs.getString("estado"));
                    lista.add(p);
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error en el buscador del DAO: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, rs);
        }
        return lista;
    }

    public boolean actualizar(Prestamo p) {
        Connection con = null;
        CallableStatement cs = null;
        boolean actualizado = false;
        String sql = "{call sp_actualizar_prestamo(?, ?, ?, ?, ?, ?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setInt(1, p.getCodigoLibro());
                cs.setInt(2, p.getIdEstudiante());
                cs.setString(3, convertirFechaAMySQL(p.getFechaPrestamo()));
                cs.setString(4, convertirFechaAMySQL(p.getFechaLimite()));
                
                if (p.getFechaDevolucion() == null || p.getFechaDevolucion().trim().isEmpty()) {
                    cs.setNull(5, java.sql.Types.DATE);
                } else {
                    cs.setString(5, convertirFechaAMySQL(p.getFechaDevolucion()));
                }
                
                cs.setString(6, p.getEstado());
                cs.setInt(7, p.getIdPrestamo());
                
                int filas = cs.executeUpdate();
                if (filas > 0) actualizado = true;
            }
        } catch (SQLException ex) {
            System.out.println(" Error al actualizar préstamo: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return actualizado;
    }

    public boolean eliminar(int idPrestamo) {
        Connection con = null;
        CallableStatement cs = null;
        boolean eliminado = false;
        String sql = "{call sp_eliminar_prestamo(?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setInt(1, idPrestamo);

                int filasAfectadas = cs.executeUpdate();
                if (filasAfectadas > 0) {
                    eliminado = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al eliminar préstamo en dao: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, null);
        }
        return eliminado;
    }

    public boolean tienePrestamoActivo(int idEstudiante, int idLibro) {
        Connection con = null;
        CallableStatement cs = null;
        ResultSet rs = null;
        boolean tieneActivo = false;
        String sql = "{call sp_tiene_prestamo_activo(?, ?)}";

        try {
            con = ConexionBD.conectar();
            if (con != null) {
                cs = con.prepareCall(sql);
                cs.setInt(1, idEstudiante);
                cs.setInt(2, idLibro);
                rs = cs.executeQuery();

                if (rs.next() && rs.getInt("total") > 0) {
                    tieneActivo = true;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al verificar préstamo activo: " + ex.getMessage());
        } finally {
            cerrarRecursos(con, cs, rs);
        }
        return tieneActivo;
    }

    private String convertirFechaAMySQL(String fechaUI) {
        if (fechaUI == null || !fechaUI.contains("/")) {
            return fechaUI;
        }
        try {
            String[] partes = fechaUI.split("/");
            if (partes.length == 3) {
                return partes[2] + "-" + partes[1] + "-" + partes[0];
            }
        } catch (Exception e) {
            System.out.println("Error de conversión de fecha: " + e.getMessage());
        }
        return fechaUI;
    }
    
    private void cerrarRecursos(Connection con, AutoCloseable ps, ResultSet rs) {
        try { if (rs != null) rs.close(); } catch (Exception e) {}
        try { if (ps != null) ps.close(); } catch (Exception e) {}
        try { if (con != null) con.close(); } catch (Exception e) {}
    }
}