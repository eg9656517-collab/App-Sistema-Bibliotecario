package Modelo;
public class Libro {
    private int codigo;
    private String titulo;
    private String autor;
    private String categoria;
    private String editorial;
    private String anoPublicacion;
    private String disponibilidad;
    private String ubicacion;
    private int cantidad;
    public Libro() {
    }

    public Libro(int codigo,int cantidad, String titulo, String autor, String categoria, String editorial, String anoPublicacion, String disponibilidad, String ubicacion) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
        this.editorial = editorial;
        this.anoPublicacion = anoPublicacion;
        this.disponibilidad = disponibilidad;
        this.ubicacion = ubicacion;
        this.cantidad = cantidad;
    }

    public int getCantidad() {
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) { this.codigo = codigo; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public String getEditorial() { return editorial; }
    public void setEditorial(String editorial) { this.editorial = editorial; }

    public String getAnoPublicacion() { return anoPublicacion; }
    public void setAnoPublicacion(String anoPublicacion) { this.anoPublicacion = anoPublicacion; }

    public String getDisponibilidad() { return disponibilidad; }
    public void setDisponibilidad(String disponibilidad) { this.disponibilidad = disponibilidad; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
}