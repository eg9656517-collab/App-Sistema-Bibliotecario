package Modelo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAORol {

    private Connection obtenerConexion() {
        return Conexion.ConexionBD.conectar();
    }

    public boolean guardar(Rol r) {
        String sql;
        Connection con = obtenerConexion();
        CallableStatement cs = null;

        try {
            if (r.getId() == 0) { 
                sql = "{call sp_insertar_rol(?, ?, ?)}";
                cs = con.prepareCall(sql);
                cs.setString(1, r.getNombreRol());
                cs.setString(2, r.getDescripcion());
                cs.setString(3, r.getEstado());
            } else {
                sql = "{call sp_modificar_rol(?, ?, ?, ?)}";
                cs = con.prepareCall(sql);
                cs.setString(1, r.getNombreRol());
                cs.setString(2, r.getDescripcion());
                cs.setString(3, r.getEstado());
                cs.setInt(4, r.getId());
            }
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al guardar/editar rol: " + e.getMessage());
            return false;
        } finally {
            try { 
                if (cs != null) cs.close(); 
                if (con != null) con.close(); 
            } catch (SQLException e) {
                System.out.println("Error al cerrar conexión en DAORol: " + e.getMessage());
            }
        }
    }

    public List<Rol> listar() {
        List<Rol> listaRoles = new ArrayList<>();
        String sql = "{call sp_listar_roles()}";
        Connection con = obtenerConexion();
        CallableStatement cs = null;
        ResultSet rs = null;

        try {
            cs = con.prepareCall(sql);
            rs = cs.executeQuery();
            while (rs.next()) {
                Rol r = new Rol(
                    rs.getInt("id_rol"),
                    rs.getString("nombre_rol"),
                    rs.getString("descripcion"),
                    rs.getString("estado")
                );
                listaRoles.add(r);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar roles: " + e.getMessage());
        } finally {
            try { 
                if (rs != null) rs.close(); 
                if (cs != null) cs.close(); 
                if (con != null) con.close(); 
            } catch (SQLException e) {
                System.out.println("Error al cerrar conexión en DAORol: " + e.getMessage());
            }
        }
        return listaRoles;
    }
}