package Modelo;
public class Usuario {
    private int id; 
    private String nombreCompleto;
    private String nombreUsuario;
    private String contrasena;
    private String correo;
    private String telefono;
    private String rol;

    public Usuario() {}
    public Usuario(int id, String nombreCompleto, String nombreUsuario, String contrasena, String correo, String telefono, String rol) {
        this.nombreCompleto = nombreCompleto;
        this.id = id;
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.correo = correo;
        this.telefono = telefono;
        this.rol = rol;
    }
    public int getId() {return id; }
    public void setId(int id) {this.id = id;}
    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nc) { this.nombreCompleto = nc; }
    
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nu) { this.nombreUsuario = nu; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String c) { this.contrasena = c; }

    public String getCorreo() { return correo; }
    public void setCorreo(String cor) { this.correo = cor; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String tel) { this.telefono = tel; }

    public String getRol() { return rol; }
    public void setRol(String r) { this.rol = r; }
}